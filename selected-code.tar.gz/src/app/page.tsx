"use client";
import React, { useState, useEffect, useCallback, useRef } from 'react';
import Link from 'next/link';
import { auth } from '@/lib/firebaseClient';
// Only one import for actions:
import { runServerSimulation, getProductProfile, runPriceSensitivityAnalysis, testServerAction } from './actions';
import ModelInfoModal from '@/components/ModelInfoModal';
import type {
  ProductSetupConfig,
  ReportData,
  SegmentShare,
  ProductProfileData,
  SensitivityPoint,
  CardData,
  MarketFactors,
  SimulationOptions,
  CoreProductDescriptions,
  FeatureDescriptions,
  VerticalDescriptions,
  MarketFactorDefinitions
} from '@/lib/types';
import { initialCardData, MAX_PRODUCTS, AVAILABLE_FEATURES_LISTS, coreProductDescriptionsData, featureDescriptionsData, verticalDescriptionsData, marketFactorDefinitions, marketScenarios } from '@/lib/constants';
import ReportDisplay from '@/components/ReportDisplay';
import SensitivityAnalysisDisplay from '@/components/SensitivityAnalysisDisplay';
import ProductProfilesDisplay from '@/components/ProductProfilesDisplay';
import ReviewCoreProductsModal from '@/components/ReviewCoreProductsModal';
import ReviewFeaturesModal from '@/components/ReviewFeaturesModal';
import ReviewVerticalsModal from '@/components/ReviewVerticalsModal';
import MarketSizingModal from '@/components/MarketSizingModal';


const CORE_PRODUCT_TYPES_CONST = Object.keys(coreProductDescriptionsData);

// Add basic styles for modals
const modalStyles = `
  <style>
    .modal-overlay { /* Styles for the modal overlay */
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
    .modal-content { /* Styles for the modal content area */
      background-color: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 600px;
      max-height: 80vh;
      overflow-y: auto;
      position: relative; /* For close button positioning */
    }
    .modal-close-btn { /* Styles for the modal close button */
      position: absolute;
      top: 15px;
      right: 15px;
      background: #eee;
      border: none;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      font-size: 18px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .modal-close-btn:hover {
      background: #ddd;
    }
    .modal-content h2 {
      margin-top: 0;
      color: #333;
      border-bottom: 1px solid #eee;
      padding-bottom: 10px;
    }
    .modal-content p, .modal-content ul {
      color: #555;
      line-height: 1.6;
    }
    .modal-content ul {
      padding-left: 20px;
    }
    .modal-content li {
      margin-bottom: 8px;
    }
    .branded-alert-title {
      font-size: 1.5em; /* Larger title */
      color: #003366; /* CNN Blue */
      margin-bottom: 15px;
    }
    .branded-alert-message {
      font-size: 1em;
      color: #333; /* Darker text for readability */
      margin-bottom: 20px;
    }
    .branded-alert-button, .branded-confirm-button {
      background-color: #007bff; /* Primary button blue */
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1em;
      transition: background-color 0.2s ease;
    }
    .branded-alert-button:hover, .branded-confirm-button:hover {
      background-color: #0056b3; /* Darker blue on hover */
    }
    .branded-confirm-buttons {
      display: flex;
      justify-content: flex-end; /* Align buttons to the right */
      gap: 10px; /* Space between buttons */
    }
    .branded-confirm-button.cancel {
      background-color: #6c757d; /* Grey for cancel */
    }
    .branded-confirm-button.cancel:hover {
      background-color: #545b62; /* Darker grey on hover */
    }
    .feature-checkbox-label {
      display: block; /* Each checkbox on a new line */
      margin-bottom: 10px; /* Space between checkboxes */
      padding: 8px;
      border-radius: 4px;
      background-color: #f8f9fa; /* Light background for each item */
      border: 1px solid #e9ecef; /* Subtle border */
    }
    .feature-checkbox-label input[type="checkbox"] {
      margin-right: 10px; /* Space between checkbox and label text */
      transform: scale(1.1); /* Slightly larger checkbox */
    }
    .feature-checkbox-label:hover {
      background-color: #e9ecef; /* Highlight on hover */
    }
    .modal-actions { /* Container for action buttons like "Select All" */
      margin-top: 20px;
      padding-top: 15px;
      border-top: 1px solid #eee;
      display: flex;
      justify-content: space-between;
    }
    .add-btn-reader {
      background: #2563eb; /* Blue for reader */
    }
    .add-btn-reader:hover {
      background: #1d4ed8; /* Darker blue */
    }
    .add-btn-streaming {
      background: #7c3aed; /* Purple for streaming */
    }
    .add-btn-streaming:hover {
      background: #6d28d9; /* Darker purple */
    }
    .add-btn-vertical {
      background: #ea580c; /* Orange for verticals */
    }
    .add-btn-vertical:hover {
      background: #c2410c; /* Darker orange */
    }
    
    .feature-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 6px 8px;
      margin-bottom: 4px;
      background-color: #f0f0f0;
      border-radius: 4px;
      font-size: 0.9em;
    }
    .feature-item span.remove {
      cursor: pointer;
      color: #cc0000;
      font-weight: bold;
      padding: 0 5px;
    }
  </style>
`;

// Helper function to initialize card data
const initialCardSetup = (): { [key: number]: CardData } => {
  const initialData: { [key: number]: CardData } = {};
  for (let i = 1; i <= MAX_PRODUCTS; i++) {
    initialData[i] = { ...initialCardData };
  }
  return initialData;
};

export default function SimulatorPage() {
  const [cardDataState, setCardDataState] = useState<{ [key: number]: CardData }>(initialCardSetup);
  const [activeProductsState, setActiveProductsState] = useState<Set<number>>(new Set([1]));
  const [expandedCards, setExpandedCards] = useState<Set<number>>(new Set());
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [currentReportTypeState, setCurrentReportTypeState] = useState<ReportType | null>(null);
  const [currentOutputTypeState, setCurrentOutputTypeState] = useState<OutputType | null>(null);
  const reportTypeDisplayRef = useRef<HTMLDivElement>(null);
  const [isReportModalVisible, setReportModalVisible] = useState(false);
  const [tempReportType, setTempReportType] = useState<ReportType | null>(null);
  const [tempOutputType, setTempOutputType] = useState<OutputType | null>(null);
  const [customModal, setCustomModal] = useState<{ visible: boolean; title: string; message: string; onConfirm?: () => void; isConfirm: boolean }>({ visible: false, title: '', message: '', isConfirm: false });
  const [isFeatureModalOpen, setIsFeatureModalOpen] = useState(false);
  const [currentCardForModal, setCurrentCardForModal] = useState<number | null>(null);
  const [currentFeatureTypeForModal, setCurrentFeatureTypeForModal] = useState<'reader' | 'streaming' | 'vertical' | null>(null);
  const [selectedFeaturesInModal, setSelectedFeaturesInModal] = useState<Set<string>>(new Set());
  const [sensitivityResults, setSensitivityResults] = useState<SensitivityPoint[] | null>(null);
  const [isAnalyzingSensitivity, setIsAnalyzingSensitivity] = useState(false);
  const [sensitivityModalProductId, setSensitivityModalProductId] = useState<number | null>(null);
  const [productProfiles, setProductProfiles] = useState<ProductProfileData[] | null>(null);
  const [isProfilesModalOpen, setIsProfilesModalOpen] = useState(false);
  const [selectedProfileProductId, setSelectedProfileProductId] = useState<number | null>(null);
  const [marketFactors, setMarketFactors] = useState<MarketFactors>({
    economicOutlook: 1.0,
    competitiveIntensity: 1.0,
    consumerTechAdoption: 1.0,
    contentExclusivity: 1.0,
    marketingEffectiveness: 1.0,
  });
  const [isMarketFactorsModalOpen, setIsMarketFactorsModalOpen] = useState(false);
  const [marketFactorInfoModalContent, setMarketFactorInfoModalContent] = useState<{ title: string; description: string } | null>(null);
  const [baseTakeRateForModalDisplay, setBaseTakeRateForModalDisplay] = useState(0.15); // Default, can be updated
  const [isReviewCoreProductsModalOpen, setIsReviewCoreProductsModalOpen] = useState(false);
  const [isReviewFeaturesModalOpen, setIsReviewFeaturesModalOpen] = useState(false);
  const [isReviewVerticalsModalOpen, setIsReviewVerticalsModalOpen] = useState(false);
  const [isMarketSizingModalVisible, setIsMarketSizingModalVisible] = useState(false);
  const [selectedVerticalForReview, setSelectedVerticalForReview] = useState<string>('');
  const [showAboutModel, setShowAboutModel] = useState(false);

  // Add Firebase Auth listener
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(user => {
      if (user) {
        // User is signed in.
        console.log("User signed in:", user.uid);
      } else {
        // User is signed out.
        console.log("User signed out");
        // Optionally, redirect to login or show a message
      }
    });
    return () => unsubscribe(); // Cleanup subscription on unmount
  }, []);

  const showBrandedAlert = useCallback((title: string, message: string) => {
    setCustomModal({ visible: true, title, message, isConfirm: false });
  }, []);

  const showBrandedConfirm = useCallback((title: string, message: string, onConfirm: () => void) => {
    setCustomModal({ visible: true, title, message, onConfirm, isConfirm: true });
  }, []);

  const closeCustomModal = () => {
    setCustomModal({ visible: false, title: '', message: '', isConfirm: false });
  };

  const handleCustomConfirm = () => {
    if (customModal.onConfirm) {
      customModal.onConfirm();
    }
    closeCustomModal();
  };

  const getPricingRangeForProduct = useCallback((product: string, verticalCount = 0) => {
    // Simplified pricing logic, expand as needed
    let min = 5, max = 20, def = 10; // Default for CNN Reader
    if (product === 'CNN Streaming') { min = 8; max = 25; def = 15; }
    if (product === 'CNN All-Access') { min = 12; max = 35; def = 20; }
    if (product === 'CNN Standalone Vertical') { min = 3; max = 15; def = 7; }
    
    // Adjust price based on number of verticals for products that are not standalone
    if (product !== 'CNN Standalone Vertical' && verticalCount > 0) {
        const verticalPriceAdjustment = verticalCount * 1; // Example: $1 per vertical
        min += verticalPriceAdjustment;
        max += verticalPriceAdjustment;
        def += verticalPriceAdjustment;
    }
    return { min, max, default: def };
  }, []);

  const updateCardState = useCallback((cardNum: number, updates: Partial<CardData>) => {
    setCardDataState(prev => {
      const currentCard = prev[cardNum];
      const newCardData = { ...currentCard, ...updates };

      // If product type changes, or verticals change for a non-standalone product, recalculate default price
      if (updates.product || (updates.verticals && newCardData.product !== 'CNN Standalone Vertical')) {
        const verticalCount = newCardData.verticals?.length || 0;
        const pricing = getPricingRangeForProduct(newCardData.product!, verticalCount);
        // Only update monthlyRate if it's not part of the explicit updates or if it's outside the new range
        if (updates.monthlyRate === undefined || newCardData.monthlyRate < pricing.min || newCardData.monthlyRate > pricing.max) {
            newCardData.monthlyRate = pricing.default;
        }
      }
      // If product type changes to Standalone Vertical, ensure only one vertical and adjust price
      if (updates.product === 'CNN Standalone Vertical') {
        newCardData.verticals = newCardData.verticals?.length > 0 ? [newCardData.verticals[0]] : [];
        const pricing = getPricingRangeForProduct(newCardData.product!, newCardData.verticals.length > 0 ? 1: 0);
        if (updates.monthlyRate === undefined || newCardData.monthlyRate < pricing.min || newCardData.monthlyRate > pricing.max) {
            newCardData.monthlyRate = pricing.default;
        }
      }


      return { ...prev, [cardNum]: newCardData };
    });
  }, [getPricingRangeForProduct]);

  const updateCardProductType = useCallback((cardNum: number, productType: string) => {
    console.log('updateCardProductType called:', cardNum, productType);
    const currentCard = cardDataState[cardNum];
    if (!currentCard) {
      console.error('No card data for:', cardNum);
      return;
    }
    
    let verticalCountForPricing = 0;
    let updatedVerticals = currentCard.verticals || [];

    if (productType === 'CNN Standalone Vertical') {
        updatedVerticals = currentCard.verticals.length > 0 ? [currentCard.verticals[0]] : []; // Keep only first or none
        verticalCountForPricing = updatedVerticals.length > 0 ? 1 : 0;
    } else {
        updatedVerticals = currentCard.verticals; // Keep all existing for other types
        verticalCountForPricing = updatedVerticals.length;
    }

    const pricing = getPricingRangeForProduct(productType, verticalCountForPricing);

    let updatedFeatures: Partial<CardData> = {
        product: productType,
        monthlyRate: pricing.default, // Set to default price for the new product type/vertical count
        verticals: updatedVerticals
    };

    // Clear features not relevant to the new product type
    if (productType === 'CNN Reader') {
      updatedFeatures.streamingFeatures = [];
    } else if (productType === 'CNN Streaming') {
      updatedFeatures.readerFeatures = [];
    } else if (productType === 'CNN Standalone Vertical') {
      updatedFeatures.readerFeatures = [];
      updatedFeatures.streamingFeatures = [];
    }
    // For CNN All-Access, no features are cleared by default, user manages them.
 
    updateCardState(cardNum, updatedFeatures);
  
    if (productType) {
      setExpandedCards(prev => {
        const newSet = new Set(prev);
        newSet.add(cardNum);
        return newSet;
      });
    } else { // Product selection cleared
      setExpandedCards(prev => {
        const newSet = new Set(prev);
        newSet.delete(cardNum);
        return newSet;
      });
      // Also reset card to initial state if product is deselected
      updateCardState(cardNum, { ...initialCardData });
    }
  }, [cardDataState, getPricingRangeForProduct, updateCardState]);

  const updateStandaloneVertical = useCallback((cardNum: number, verticalName: string) => {
    const currentCard = cardDataState[cardNum];
    if (currentCard && currentCard.product === 'CNN Standalone Vertical') {
      const newVerticals = verticalName ? [verticalName] : [];
      const pricing = getPricingRangeForProduct(currentCard.product, newVerticals.length);
      updateCardState(cardNum, { 
        verticals: newVerticals,
        monthlyRate: pricing.default // Reset to default price for this vertical selection
      });
    }
  }, [cardDataState, getPricingRangeForProduct, updateCardState]);

  const updateFeatureList = useCallback((cardNum: number, type: 'reader' | 'streaming' | 'vertical', newFeatures: string[]) => {
    const currentCard = cardDataState[cardNum];
    if (!currentCard) return;

    let updatePayload: Partial<CardData> = {};
    if (type === 'reader') updatePayload.readerFeatures = newFeatures;
    else if (type === 'streaming') updatePayload.streamingFeatures = newFeatures;
    else if (type === 'vertical') {
      updatePayload.verticals = newFeatures;
      // If it's not a standalone vertical, changing verticals might impact price range
      if (currentCard.product !== 'CNN Standalone Vertical') {
        const pricing = getPricingRangeForProduct(currentCard.product!, newFeatures.length);
        // Only update price if it's outside new range or not explicitly set
        if (currentCard.monthlyRate < pricing.min || currentCard.monthlyRate > pricing.max) {
            updatePayload.monthlyRate = pricing.default;
        }
      }
    }
    updateCardState(cardNum, updatePayload);
  }, [cardDataState, getPricingRangeForProduct, updateCardState]);

  const updatePriceDisplayHTML = useCallback((cardNum: number): string => {
    const cardConfig = cardDataState[cardNum];
    if (!cardConfig || !cardConfig.product) return 'N/A';

    const { monthlyRate, pricingType, discount } = cardConfig;
    let display = `Monthly: $${monthlyRate.toFixed(2)}`;

    if (pricingType === 'annual' || pricingType === 'both') {
      let annualPrice = monthlyRate * 12;
      let discountText = "";
      if (discount === 'free') {
        annualPrice = monthlyRate * 11;
        discountText = " (1 month free)";
      } else if (discount === '30') {
        annualPrice *= 0.7;
        discountText = " (30% off)";
      } else if (discount === '50') {
        annualPrice *= 0.5;
        discountText = " (50% off)";
      }
      const perMonthEquivalent = annualPrice / 12;
      display += `<br/>Annual: $${annualPrice.toFixed(2)}${discountText} (equiv. $${perMonthEquivalent.toFixed(2)}/mo)`;
    }
    return display;
  }, [cardDataState]);

  const updatePrice = useCallback((cardNum: number, price: number) => {
    updateCardState(cardNum, { monthlyRate: price });
  }, [updateCardState]);

  const updatePricingType = useCallback((cardNum: number, pricingType: string) => {
    const currentCard = cardDataState[cardNum];
    if (!currentCard) return;

    const updates: Partial<CardData> = { pricingType };
    // If switching away from a type that had a discount, clear the discount
    if (pricingType === 'monthly' && currentCard.discount) {
      updates.discount = ""; // Clear discount if only monthly
    }
    updateCardState(cardNum, updates);
  }, [cardDataState, updateCardState]);

  const updateDiscount = useCallback((cardNum: number, discountValue: string) => {
    updateCardState(cardNum, { discount: discountValue });
  }, [updateCardState]);

  const clearAllSelections = useCallback(() => {
    showBrandedConfirm(
      "Confirm Clear",
      "Are you sure you want to clear all product selections and configurations? This action cannot be undone.",
      () => {
        setCardDataState(initialCardSetup());
        setActiveProductsState(new Set([1])); // Keep first product active by default
        setExpandedCards(new Set());
        setReportData(null);
        setCurrentReportTypeState(null);
        setCurrentOutputTypeState(null);
        if (reportTypeDisplayRef.current) {
          reportTypeDisplayRef.current.innerHTML = 'Report Type: Not Set';
        }
        showBrandedAlert('Selections Cleared', 'All product configurations have been reset.');
      }
    );
  }, [showBrandedAlert, showBrandedConfirm]); // Removed initialCardSetup from deps as it's stable

  const toggleCardExpansion = useCallback((cardNum: number) => {
    const cardConfig = cardDataState[cardNum];
    // Only allow expansion if a product is selected for that card
    if (cardConfig && cardConfig.product) {
      setExpandedCards(prev => {
        const newSet = new Set(prev);
        if (newSet.has(cardNum)) {
          newSet.delete(cardNum);
        } else {
          newSet.add(cardNum);
        }
        return newSet;
      });
    } else {
      // Optionally, show an alert if trying to expand an unconfigured card
      // showBrandedAlert("Product Not Selected", "Please select a product for this card to see more options.");
    }
  }, [cardDataState]); // Removed showBrandedAlert from deps for now

  const toggleProduct = (cardId: number) => {
    setActiveProductsState(prev => {
      const newSet = new Set(prev);
      if (newSet.has(cardId)) {
        if (newSet.size > 1) { // Prevent deactivating the last active product
          newSet.delete(cardId);
          // If deactivated, also collapse it and potentially clear its config if desired
          setExpandedCards(oldExpanded => {
            const newExpanded = new Set(oldExpanded);
            newExpanded.delete(cardId);
            return newExpanded;
          });
          // Optionally, reset the card data when deactivated
          // updateCardState(cardId, { ...initialCardData }); 
        } else {
          showBrandedAlert("Action Denied", "At least one product must be active in the simulator.");
        }
      } else {
        if (newSet.size < MAX_PRODUCTS) {
          newSet.add(cardId);
        } else {
          showBrandedAlert("Limit Reached", `You can only have a maximum of ${MAX_PRODUCTS} products active.`);
        }
      }
      return newSet;
    });
  };

  const addFeaturesModalOpen = (cardId: number, type: 'reader' | 'streaming' | 'vertical') => {
    const currentCard = cardDataState[cardId];
    if (!currentCard) return;

    setCurrentCardForModal(cardId);
    setCurrentFeatureTypeForModal(type);
    let existingFeatures = new Set<string>();
    if (type === 'reader') existingFeatures = new Set(currentCard.readerFeatures);
    else if (type === 'streaming') existingFeatures = new Set(currentCard.streamingFeatures);
    else if (type === 'vertical') existingFeatures = new Set(currentCard.verticals);
    
    setSelectedFeaturesInModal(existingFeatures);
    setIsFeatureModalOpen(true);
  };

  const handleModalFeatureToggle = (featureName: string) => {
    setSelectedFeaturesInModal(prev => {
      const newSet = new Set(prev);
      if (newSet.has(featureName)) {
        newSet.delete(featureName);
      } else {
        newSet.add(featureName);
      }
      return newSet;
    });
  };

  const handleModalSelectAllFeatures = () => {
    if (!currentFeatureTypeForModal) return;
    const allAvailable = AVAILABLE_FEATURES_LISTS[currentFeatureTypeForModal];
    setSelectedFeaturesInModal(new Set(allAvailable));
  };

  const addSelectedFeaturesFromModal = () => {
    if (currentCardForModal !== null && currentFeatureTypeForModal) {
      updateFeatureList(currentCardForModal, currentFeatureTypeForModal, Array.from(selectedFeaturesInModal));
    }
    setIsFeatureModalOpen(false);
    setCurrentCardForModal(null);
    setCurrentFeatureTypeForModal(null);
  };

  const removeFeatureFromList = (cardNum: number, type: 'reader' | 'streaming' | 'vertical', featureToRemove: string) => {
    const currentCard = cardDataState[cardNum];
    if (!currentCard) return;

    let currentFeatures: string[] = [];
    if (type === 'reader') currentFeatures = currentCard.readerFeatures;
    else if (type === 'streaming') currentFeatures = currentCard.streamingFeatures;
    else if (type === 'vertical') currentFeatures = currentCard.verticals;

    const newFeatures = currentFeatures.filter(f => f !== featureToRemove);
    updateFeatureList(cardNum, type, newFeatures);
  };

  const handleSetReportType = () => { setReportModalVisible(true); };

  const generateReportFromModal = () => {
    if (tempReportType && tempOutputType) {
      setCurrentReportTypeState(tempReportType);
      setCurrentOutputTypeState(tempOutputType);
      if (reportTypeDisplayRef.current) {
        reportTypeDisplayRef.current.innerHTML = `Report Type: ${tempReportType}, Output: ${tempOutputType}`;
      }
      setReportModalVisible(false);
    } else {
      showBrandedAlert('Selection Incomplete', 'Please select both a report type and an output type.');
    }
  };

  const handleRunSimulation = async () => {
    if (!currentReportTypeState || !currentOutputTypeState) {
      showBrandedAlert('Configuration Required', 'Please set report type first by clicking "Set Report Type"');
      return;
    }
    const activeConfigured = Array.from(activeProductsState)
      .filter(id => cardDataState[id] && cardDataState[id].product)
      .map(id => ({ ...cardDataState[id], id, isActive: true } as ProductSetupConfig)); // Ensure 'id' is part of the config

    if (activeConfigured.length === 0) {
      showBrandedAlert('Configuration Required', 'Please configure at least one active product before running simulation');
      return;
    }

    console.log("Starting simulation with the following configurations:");
    console.log("Active Configured Products:", JSON.stringify(activeConfigured, null, 2));
    console.log("Report Type:", currentReportTypeState);
    console.log("Output Type:", currentOutputTypeState);
    console.log("Market Factors:", JSON.stringify(marketFactors, null, 2));
    const simulationOptions: SimulationOptions = { 
      takeThreshold: baseTakeRateForModalDisplay, // Use the state variable
      drnFactor: 1.0, // Example, make configurable if needed
      allocationMethod: 'proportional' as const // Example, make configurable
    };
    console.log("Simulation Options (to be passed):", JSON.stringify(simulationOptions, null, 2));


    setIsSimulating(true);
    setReportData(null); // Clear previous report
    const reportContainer = document.getElementById('reportContainer');
    const reportContentDiv = document.getElementById('reportContent'); // Assuming this ID exists within reportContainer
    if (reportContainer && reportContentDiv) {
      reportContentDiv.innerHTML = `<div class="simulation-loading"><div class="spinner"></div>Running simulation...</div>`;
      reportContainer.style.display = 'block';
      reportContainer.scrollIntoView({ behavior: 'smooth' });
    }

    try {
      console.log("Calling runServerSimulation action...");
      const serverReportData = await runServerSimulation(
        activeConfigured,
        currentReportTypeState,
        currentOutputTypeState,
        marketFactors, // Pass the current market factors
        simulationOptions // Pass the defined simulation options
      );
      console.log("Received data from runServerSimulation:", serverReportData);

      if (serverReportData) {
        setReportData(serverReportData);
        // ReportDisplay component will handle rendering if reportData is not null
      } else {
        console.error("Simulation Error: Failed to generate report data from the server (serverReportData is null or undefined).");
        showBrandedAlert("Simulation Error", "Failed to generate report data from the server.");
        if (reportContentDiv) reportContentDiv.innerHTML = '<p style="color:red; text-align:center;">Simulation failed: No data received.</p>';
      }
    } catch (error: any) {
      console.error("Error during runServerSimulation call or processing:", error);
      let errorMessage = "An unexpected error occurred during simulation.";
      if (error.message) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      showBrandedAlert("Simulation Error", errorMessage);
      if (reportContentDiv) reportContentDiv.innerHTML = `<p style="color:red; text-align:center;">An unexpected error occurred: ${errorMessage}</p>`;
    } finally {
      setIsSimulating(false);
    }
  };

  const downloadReport = () => {
    if (!reportData) {
      showBrandedAlert('No Report', 'No report data available to download.');
      return;
    }
    try {
      const jsonData = JSON.stringify(reportData, null, 2);
      const blob = new Blob([jsonData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'simulation_report.json';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading report:", error);
      showBrandedAlert('Download Error', 'Failed to download the report.');
    }
  };

  const handleShowProfiles = async () => {
    const activeProductConfigs = Array.from(activeProductsState)
      .map(id => cardDataState[id])
      .filter(config => config && config.product) as ProductSetupConfig[];

    if (activeProductConfigs.length === 0) {
      showBrandedAlert("No Products", "Please configure and activate products to view profiles.");
      return;
    }

    setIsProfilesModalOpen(true); // Open modal immediately to show loading state
    setProductProfiles(null); // Clear previous profiles

    try {
      const profilesPromises = activeProductConfigs.map(config =>
        // Ensure 'id' is passed if getProductProfile expects it as a separate arg
        // If getProductProfile expects the full config (which includes id), this is fine
        getProductProfile(config.id, activeProductConfigs) // Assuming config.id is the product ID
      );
      const profilesResults = await Promise.all(profilesPromises);
      const validProfiles = profilesResults.filter(p => p !== null) as ProductProfileData[];
      setProductProfiles(validProfiles);
      if (validProfiles.length === 0) {
        showBrandedAlert("Profile Error", "Could not generate profiles for the selected products.");
      }
    } catch (error) {
      console.error("Error fetching product profiles:", error);
      showBrandedAlert("Profile Error", "An error occurred while fetching product profiles.");
      setProductProfiles([]); // Set to empty array on error to stop loading
    }
  };

  const handleProfileProductOptionClick = (productId: number) => {
    setSelectedProfileProductId(productId);
    // The ProductProfilesDisplay component will use this to show details
  };

  const displaySelectedProfiles = async () => {
    // This function might be redundant if ProductProfilesDisplay handles selection
    if (selectedProfileProductId === null || !productProfiles) return;
    const profile = productProfiles.find(p => p.productId === selectedProfileProductId);
    if (profile) {
      // Logic to display this specific profile, perhaps in another modal or dedicated area
      console.log("Displaying profile:", profile);
      // For now, just log it. UI update would go here.
    }
  };

  const openSensitivityModal = (productId: number) => {
    setSensitivityModalProductId(productId);
    setSensitivityResults(null); // Clear previous results
    // Modal will be opened by setting isAnalyzingSensitivity or a dedicated state
  };

  const handlePriceSensitivityAnalysis = async () => {
    if (sensitivityModalProductId === null) {
      showBrandedAlert("Error", "No product selected for sensitivity analysis.");
      return;
    }
    const baseConfig = cardDataState[sensitivityModalProductId];
    if (!baseConfig || !baseConfig.product) {
      showBrandedAlert("Error", "Product configuration not found for sensitivity analysis.");
      return;
    }

    // Define a sensible price range, perhaps based on current price or product type
    const currentPrice = baseConfig.monthlyRate;
    const priceRange = {
      min: Math.max(1, currentPrice - 5), // Ensure min is not too low
      max: currentPrice + 10,
      steps: 10 // Number of price points to test
    };
    const simulationOptions: SimulationOptions = { 
        takeThreshold: baseTakeRateForModalDisplay, 
        drnFactor: 1.0, 
        allocationMethod: 'proportional' 
    };


    setIsAnalyzingSensitivity(true);
    setSensitivityResults(null); // Clear previous results

    try {
      const results = await runPriceSensitivityAnalysis(
        {...baseConfig, id: sensitivityModalProductId, isActive: true}, // Pass the full config including id
        priceRange,
        marketFactors, // Pass current market factors
        simulationOptions // Pass simulation options
      );
      setSensitivityResults(results);
      if (!results || results.length === 0) {
        showBrandedAlert("Analysis Info", "Sensitivity analysis completed, but no data points were generated. Check console for details.");
      }
    } catch (error: any) {
      console.error("Error during price sensitivity analysis:", error);
      showBrandedAlert("Analysis Error", `Failed to run sensitivity analysis: ${error.message}`);
      setSensitivityResults([]); // Set to empty to stop loading state
    } finally {
      setIsAnalyzingSensitivity(false);
    }
  };

  const closeSensitivityResultsModal = () => {
    setSensitivityModalProductId(null); // This will hide the modal
    setSensitivityResults(null);
  };

  const runAnalysisForProduct = async (productId: number) => {
    // This function now just opens the modal. The analysis is run from the modal.
    openSensitivityModal(productId);
  };

  const openMarketFactorsModal = () => {
    // Potentially load current baseTakeRate from a more central config if needed
    // For now, using the state variable directly.
    setIsMarketFactorsModalOpen(true);
  };
  const closeMarketFactorsModal = () => setIsMarketFactorsModalOpen(false);

  const handleMarketFactorChange = (factorName: keyof MarketFactors, value: string) => {
    const numericValue = parseFloat(value);
    if (!isNaN(numericValue) && numericValue >= 0 && numericValue <= 2) { // Example range
      setMarketFactors(prev => ({ ...prev, [factorName]: numericValue }));
    }
  };

  const handleMarketScenarioChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const scenarioName = event.target.value as keyof typeof marketScenarios;
    if (marketScenarios[scenarioName]) {
      setMarketFactors(marketScenarios[scenarioName].factors);
      setBaseTakeRateForModalDisplay(marketScenarios[scenarioName].baseTakeRate);
    } else if (scenarioName === "custom") {
      // Allow users to set custom values, don't change anything here
      // or reset to some default custom state if preferred
    }
  };

  const applyMarketFactors = () => {
    // The factors are already updated in state by handleMarketFactorChange and handleMarketScenarioChange
    // This function primarily closes the modal.
    // Optionally, trigger a re-simulation or display a confirmation.
    console.log("Market factors applied:", marketFactors, "Base Take Rate:", baseTakeRateForModalDisplay);
    showBrandedAlert("Market Factors Updated", "The market factors and base take rate have been updated for subsequent simulations.");
    closeMarketFactorsModal();
  };

  useEffect(() => {
    // This effect can be used to react to marketFactors changes if needed,
    // e.g., updating a display or triggering other logic.
    console.log("Market factors state changed to:", marketFactors);
    console.log("Base take rate for modal display changed to:", baseTakeRateForModalDisplay);
  }, [marketFactors, baseTakeRateForModalDisplay]);

  const openMarketFactorInfoModal = (factorKey: keyof MarketFactors) => { setMarketFactorInfoModalContent(marketFactorDefinitions[factorKey]); };
  const openReviewCoreProductsModal = () => setIsReviewCoreProductsModalOpen(true);
  const openReviewFeaturesModal = () => setIsReviewFeaturesModalOpen(true);
  const openReviewVerticalsModal = () => setIsReviewVerticalsModalOpen(true);
  const handleVerticalReviewSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedVerticalForReview(e.target.value);
  };

  const updateCardUI = useCallback((cardNum: number, productType: string) => {
    console.log('updateCardUI called for card:', cardNum, 'product:', productType);
    const cardElement = document.querySelector(`.card[data-card="${cardNum}"]`);
    if (!cardElement) {
      console.error('Card element not found for:', cardNum);
      return;
    }

    const contentDiv = cardElement.querySelector('.content') as HTMLElement;
    if (!contentDiv) {
      console.error('Content div not found for card:', cardNum);
      return;
    }
    
    contentDiv.innerHTML = ''; 

    if (!productType) { 
        console.log('No product type for card', cardNum, 'clearing content.');
        return;
    }

    const currentCardConfig = cardDataState[cardNum];
    if (!currentCardConfig) {
      console.error('No card config found for:', cardNum, 'in updateCardUI');
      return;
    }
    
    let verticalCountForPricing = currentCardConfig.verticals?.length || 0;
    if (productType === 'CNN Standalone Vertical') {
      verticalCountForPricing = currentCardConfig.verticals?.length > 0 ? 1 : 0;
    }
    const pricing = getPricingRangeForProduct(productType, verticalCountForPricing);

    let featuresHtml = ''; 

    if (productType === 'CNN Standalone Vertical') {
      featuresHtml += `
        <div>
            <label class="content-label">Select Vertical</label>
            <select class="vertical-select-standalone" onchange="window.updateStandaloneVerticalWrapper(${cardNum}, this.value)">
                <option value="">-- Select a Vertical --</option>
                ${AVAILABLE_FEATURES_LISTS.vertical.map(v => 
                    `<option value="${v}" ${currentCardConfig.verticals && currentCardConfig.verticals[0] === v ? 'selected' : ''}>${v}</option>`
                ).join('')}
            </select>
        </div>
      `;
    } else {
      if (productType === 'CNN Reader' || productType === 'CNN All-Access') {
        featuresHtml += `
          <div>
            <label class="content-label">Reader Features (<span class="reader-count">${currentCardConfig.readerFeatures?.length || 0}</span> selected)</label>
            <button class="add-btn add-btn-reader" onclick="window.addFeaturesWrapper(${cardNum}, 'reader')">+ Add</button>
            <div class="feature-list reader-list">
              ${(currentCardConfig.readerFeatures || []).map(f => `
                <div class="feature-item">
                  <span>${f}</span>
                  <span class="remove" onclick="window.removeFeatureWrapper(${cardNum}, 'reader', '${f.replace(/'/g,"\\'")}')">×</span>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }
      if (productType === 'CNN Streaming' || productType === 'CNN All-Access') {
        featuresHtml += `
          <div>
            <label class="content-label">Streaming Features (<span class="streaming-count">${currentCardConfig.streamingFeatures?.length || 0}</span> selected)</label>
            <button class="add-btn add-btn-streaming" onclick="window.addFeaturesWrapper(${cardNum}, 'streaming')">+ Add</button>
            <div class="feature-list streaming-list">
              ${(currentCardConfig.streamingFeatures || []).map(f => `
                <div class="feature-item">
                  <span>${f}</span>
                  <span class="remove" onclick="window.removeFeatureWrapper(${cardNum}, 'streaming', '${f.replace(/'/g,"\\'")}')">×</span>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }
      // Verticals for non-Standalone products
      if (productType !== 'CNN Standalone Vertical') { // Ensure this condition is correct
          featuresHtml += `
            <div>
              <label class="content-label">Verticals (<span class="vertical-count">${currentCardConfig.verticals?.length || 0}</span> selected)</label>
              <button class="add-btn add-btn-vertical" onclick="window.addFeaturesWrapper(${cardNum}, 'vertical')">+ Add</button>
              <div class="feature-list vertical-list">
                ${(currentCardConfig.verticals || []).map(f => `
                  <div class="feature-item">
                    <span>${f}</span>
                    <span class="remove" onclick="window.removeFeatureWrapper(${cardNum}, 'vertical', '${f.replace(/'/g,"\\'")}')">×</span>
                  </div>
                `).join('')}
              </div>
            </div>
          `;
      }
    }
    
    let pricingHtml = `
      <label class="content-label">Configure Pricing (choose Terms + Price)</label>
      <div class="btn-group">
        <button class="${currentCardConfig.pricingType === 'monthly' ? 'active' : ''}" onclick="window.setPricingWrapper(${cardNum}, 'monthly', this)">Monthly Only</button>
        <button class="${currentCardConfig.pricingType === 'annual' ? 'active' : ''}" onclick="window.setPricingWrapper(${cardNum}, 'annual', this)">Annual Only</button>
        <button class="${currentCardConfig.pricingType === 'both' ? 'active' : ''}" onclick="window.setPricingWrapper(${cardNum}, 'both', this)">Both</button>
      </div>
      <div class="discount-section">
        ${(currentCardConfig.pricingType === 'both' || currentCardConfig.pricingType === 'annual') ? `
          <div class="discount-options">
            <h4>Select Discount (for Annual Term)</h4><hr />
            <div class="discount-option"><label><input type="radio" name="discount${cardNum}" value="free" ${currentCardConfig.discount === 'free' ? 'checked' : ''} onchange="window.setDiscountWrapper(${cardNum}, 'free')" /> 1 Mo Free (Annual)</label></div>
            <div class="discount-option"><label><input type="radio" name="discount${cardNum}" value="30" ${currentCardConfig.discount === '30' ? 'checked' : ''} onchange="window.setDiscountWrapper(${cardNum}, '30')" /> 30% off (Annual)</label></div>
            <div class="discount-option"><label><input type="radio" name="discount${cardNum}" value="50" ${currentCardConfig.discount === '50' ? 'checked' : ''} onchange="window.setDiscountWrapper(${cardNum}, '50')" /> 50% off (Annual)</label></div>
            <div class="discount-option"><label><input type="radio" name="discount${cardNum}" value="" ${!currentCardConfig.discount ? 'checked' : ''} onchange="window.setDiscountWrapper(${cardNum}, '')" /> No Discount</label></div>
          </div>
        ` : ''}
      </div>
      <div class="price-slider-container">
        <div class="price-range-labels">
          <span>$${pricing.min.toFixed(2)}</span>
          <span>$${pricing.max.toFixed(2)}</span>
        </div>
        <input type="range" 
          min="${pricing.min}" 
          max="${pricing.max}" 
          value="${currentCardConfig.monthlyRate}" 
          class="price-slider" 
          step="0.01" 
          onchange="window.updatePriceWrapper(${cardNum}, parseFloat(this.value));"
          oninput="this.parentElement.nextElementSibling.querySelector('.price-value').textContent = '$' + parseFloat(this.value).toFixed(2);"
        />
      </div>
      <label class="price-label">Selected Monthly Price: <span class="price-value">$${currentCardConfig.monthlyRate.toFixed(2)}</span></label>
      <div class="pricing-display">${updatePriceDisplayHTML(cardNum)}</div>
      <button class="analyze-button" onclick="window.runAnalysisForProductWrapper(${cardNum})" ${isAnalyzingSensitivity && sensitivityModalProductId === cardNum ? 'disabled' : ''}>
        ${isAnalyzingSensitivity && sensitivityModalProductId === cardNum ? 'Analyzing...' : 'Analyze Price Sensitivity'}
      </button>
    `;
    
    contentDiv.innerHTML = featuresHtml + pricingHtml;

  }, [cardDataState, getPricingRangeForProduct, updatePriceDisplayHTML, isAnalyzingSensitivity, sensitivityModalProductId]); // Removed direct function calls from deps, they are stable if wrapped in useCallback

  // Update card UIs when state changes
  useEffect(() => {
    console.log('useEffect for UI update triggered. Expanded cards:', Array.from(expandedCards));
    Object.keys(cardDataState).forEach(cardIdStr => {
      const cardNum = parseInt(cardIdStr);
      const cardConfig = cardDataState[cardNum];
      const isExpandedBySet = expandedCards.has(cardNum);
      const hasProductSelected = !!cardConfig?.product;
      
      // A card's content should be rendered if it's active, has a product, AND is expanded.
      // Or, if it's active and has a product (even if not explicitly in expandedCards set, e.g. newly selected product)
      if (activeProductsState.has(cardNum) && hasProductSelected) {
         // console.log(`Updating UI for card ${cardNum} because it's active and has product: ${cardConfig.product}`);
         updateCardUI(cardNum, cardConfig.product!);
      } else if (!hasProductSelected && activeProductsState.has(cardNum)) {
         // console.log(`Clearing UI for card ${cardNum} because product was deselected but card is active.`);
         updateCardUI(cardNum, ''); // Clear content if product is removed
      }
      // If a card is inactive, its UI is handled by the main render (overlay)
    });
  }, [cardDataState, expandedCards, activeProductsState, updateCardUI]);


  // Add debug logging for state changes
  useEffect(() => {
    console.log('Expanded cards changed:', Array.from(expandedCards));
    console.log('Active products changed:', Array.from(activeProductsState));
    console.log('Card data changed:', cardDataState);
  }, [expandedCards, activeProductsState, cardDataState]);

  // Initialize report type display
  useEffect(() => {
    if (reportTypeDisplayRef.current) {
      reportTypeDisplayRef.current.innerHTML = 'Report Type: Not Set';
    }
  }, []);

  // Inject modal styles
  useEffect(() => {
    const styleTag = document.createElement('style');
    styleTag.innerHTML = modalStyles;
    document.head.appendChild(styleTag);
    return () => {
      document.head.removeChild(styleTag);
    };
  }, []);

  // Expose functions to window - ensure these are stable or wrapped in useCallback
  useEffect(() => {
    // @ts-ignore
    window.updateStandaloneVerticalWrapper = updateStandaloneVertical;
    // @ts-ignore
    window.addFeaturesWrapper = addFeaturesModalOpen;
    // @ts-ignore
    window.removeFeatureWrapper = removeFeatureFromList;
    // @ts-ignore
    window.setPricingWrapper = (cardNum: number, type: string, buttonEl: HTMLElement) => {
        updatePricingType(cardNum, type);
        // Optional: Update active class on buttons if not handled by React re-render
        const group = buttonEl.parentElement;
        if (group) {
            Array.from(group.children).forEach(child => child.classList.remove('active'));
        }
        buttonEl.classList.add('active');
    };
    // @ts-ignore
    window.setDiscountWrapper = updateDiscount;
    // @ts-ignore
    window.updatePriceWrapper = updatePrice;
    // @ts-ignore
    window.runAnalysisForProductWrapper = runAnalysisForProduct; // Expose the function that opens the modal

    return () => { // Cleanup
        // @ts-ignore
        delete window.updateStandaloneVerticalWrapper;
        // @ts-ignore
        delete window.addFeaturesWrapper;
        // @ts-ignore
        delete window.removeFeatureWrapper;
        // @ts-ignore
        delete window.setPricingWrapper;
        // @ts-ignore
        delete window.setDiscountWrapper;
        // @ts-ignore
        delete window.updatePriceWrapper;
        // @ts-ignore
        delete window.runAnalysisForProductWrapper;
    };
  }, [updateStandaloneVertical, addFeaturesModalOpen, removeFeatureFromList, updatePricingType, updateDiscount, updatePrice, runAnalysisForProduct]);


  // Render the complete UI
  return (
    <div>
      <div className="main-header">
        <div className="logo-container">
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/b/b1/CNN.svg" 
            alt="CNN" 
            data-ai-hint="news logo" 
            className="cnn-logo"
          />
        </div>
        <div className="powered-by-container">
          <span className="powered-by-text">Powered by:</span>
          {/* Add your powered by logos/text here */}
        </div>
      </div>
      <div className="controls-section">
        <div className="controls-left-area">
           <div className="header-tam-info">
              <div className="tam-display">TAM Universe = 105,624,640<button className="learn-more-link" onClick={() => setIsMarketSizingModalVisible(true)}>Click here to learn more</button></div>
           </div>
           <button className="header-button set-report-button set-report-button-controls" onClick={handleSetReportType} disabled={isSimulating || isAnalyzingSensitivity}><span style={{ marginRight: '5px' }}>📊</span> Set Report Type</button>
           <div className="report-type-display-controls-info" ref={reportTypeDisplayRef}></div>
        </div>
        <button className="clear-button" onClick={clearAllSelections} disabled={isSimulating || isAnalyzingSensitivity}><span style={{ marginRight: '5px' }}>🗑️</span> Clear All Selections</button>

        <div className="header-buttons">
          <button className="header-button run-simulation-button" onClick={handleRunSimulation} disabled={isSimulating || isAnalyzingSensitivity}><span style={{ marginRight: '5px' }}>▶️</span> {isSimulating ? 'Simulating...' : 'Run Simulation'}</button>
          <button className="header-button show-profiles-button" onClick={handleShowProfiles} disabled={isSimulating || isAnalyzingSensitivity}><span style={{ marginRight: '5px' }}>👥</span> Show Profiles</button>
          <button className="header-button market-factors-button" onClick={openMarketFactorsModal} disabled={isSimulating || isAnalyzingSensitivity}>
            <span style={{ marginRight: '5px' }}>⚙️</span> Market Factors</button>
          <button 
            className="header-button" 
            style={{ background: '#6c757d', color: 'white' }}
            onClick={() => setShowAboutModel(true)}
          >
            <span style={{ marginRight: '5px' }}>📊</span> About the Model
          </button>
          <button className="header-button" style={{background: '#6f42c1', color: 'white'}} onClick={openReviewCoreProductsModal}><span style={{ marginRight: '5px' }}>📰</span> Review Core News Products</button>
          <button className="header-button" style={{background: '#fd7e14', color: 'white'}} onClick={openReviewFeaturesModal}><span style={{ marginRight: '5px' }}>✨</span> Review Features</button>
          <button className="header-button" style={{background: '#20c997', color: 'white'}} onClick={openReviewVerticalsModal}><span style={{ marginRight: '5px' }}>🌿</span> Review Verticals</button>
        </div>

        <h2 className="controls-section-h2">Select Products to Include in Simulation</h2>
        <div className="product-toggle-container">
          {Object.keys(cardDataState).map((cardIdStr) => {
            const cardNum = parseInt(cardIdStr);
            return (
              <button
                key={cardNum}
                className={`product-toggle-btn ${activeProductsState.has(cardNum) ? 'active' : ''}`}
                onClick={() => toggleProduct(cardNum)}
                disabled={isSimulating || isAnalyzingSensitivity}
              >
                Product {cardNum} {activeProductsState.has(cardNum) ? '(Active)' : '(Inactive)'}
              </button>
            );
          })}
        </div>
      </div>

      <div className="card-container">
        {Object.keys(cardDataState).map((cardIdStr) => {
          const cardNum = parseInt(cardIdStr);
          const cardConfig = cardDataState[cardNum];
          
          const isExpandedBySet = expandedCards.has(cardNum);
          const hasProductSelected = !!cardConfig?.product;
          // A card is considered "effectively expanded" if it's in the expandedCards set OR if a product has just been selected for it (to show content immediately)
          // However, the content div itself should only render if the card is active AND has a product.
          // The updateCardUI useEffect handles populating .content based on activeProductsState and cardConfig.product.

          return (
            <div className={`card ${!activeProductsState.has(cardNum) ? 'inactive' : ''}`} data-card={cardNum.toString()} key={cardNum}>
              {!activeProductsState.has(cardNum) && (
                <div className="inactive-overlay" style={{
                  position: 'absolute', top: 0, right: 0, bottom:0, left:0,
                  background: 'rgba(100,100,100,0.3)', padding: '5px 10px',
                  fontSize: '12px', color: '#333', zIndex: 1, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'bold'
                }}>
                  INACTIVE
                </div>
              )}
              <div className="header" onClick={() => toggleCardExpansion(cardNum)} style={{ cursor: cardConfig?.product ? 'pointer' : 'default' }}>
                {cardConfig?.product || `PRODUCT ${cardNum}`}
                {cardConfig?.product && <span className={`arrow ${expandedCards.has(cardNum) ? 'up' : 'down'}`}></span>}
              </div>
              <select 
                className="product-select" 
                value={cardConfig?.product || ''} 
                onChange={(e) => {
                  updateCardProductType(cardNum, e.target.value);
                }}
                disabled={!activeProductsState.has(cardNum) || isSimulating || isAnalyzingSensitivity}
              >
                <option value="">Select Base Product</option>
                <option value="CNN Reader">CNN Reader</option>
                <option value="CNN Streaming">CNN Streaming</option>
                <option value="CNN All-Access">CNN All-Access</option>
                <option value="CNN Standalone Vertical">CNN Standalone Vertical</option>
              </select>

              {/* Content div is always present but populated by updateCardUI if conditions met */}
              {/* It will be visible if expandedCards.has(cardNum) AND activeProductsState.has(cardNum) AND cardConfig?.product */}
              {/* The useEffect for updateCardUI handles showing/hiding/populating content */}
              <div className="content" style={{ display: expandedCards.has(cardNum) && activeProductsState.has(cardNum) && cardConfig?.product ? 'block' : 'none' }}>
                {/* Content will be populated by updateCardUI */}
              </div>
            </div>
          );
        })}
      </div>

      {/* Report Display Area */}
      <div id="reportContainer" style={{ display: reportData ? 'block' : 'none', marginTop: '20px', padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
        <h2 style={{ textAlign: 'center' }}>Simulation Report</h2>
        <div id="reportContent">
          {isSimulating && <div className="simulation-loading"><div className="spinner"></div>Running simulation...</div>}
          {reportData && !isSimulating && <ReportDisplay data={reportData} />}
        </div>
        {reportData && !isSimulating && (
          <button onClick={downloadReport} style={{ marginTop: '10px', padding: '8px 15px', cursor: 'pointer' }}>
            Download Report (JSON)
          </button>
        )}
      </div>

      {/* Modals */}
      {isReportModalVisible && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button onClick={() => setReportModalVisible(false)} className="modal-close-btn">&times;</button>
            <h2>Set Report Configuration</h2>
            <div>
              <label>Report Type:</label>
              <select value={tempReportType || ''} onChange={e => setTempReportType(e.target.value as ReportType)}>
                <option value="">Select Type</option>
                <option value="marketShare">Market Share</option>
                <option value="revenue">Revenue</option>
                <option value="profile">Profile</option>
              </select>
            </div>
            <div style={{ marginTop: '10px' }}>
              <label>Output Type:</label>
              <select value={tempOutputType || ''} onChange={e => setTempOutputType(e.target.value as OutputType)}>
                <option value="">Select Output</option>
                <option value="total">Total</option>
                <option value="segment">By Segment</option>
              </select>
            </div>
            <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <button onClick={generateReportFromModal} className="branded-alert-button">Set Report</button>
            </div>
          </div>
        </div>
      )}

      {isFeatureModalOpen && currentCardForModal !== null && currentFeatureTypeForModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button onClick={() => setIsFeatureModalOpen(false)} className="modal-close-btn">&times;</button>
            <h2>Add {currentFeatureTypeForModal.charAt(0).toUpperCase() + currentFeatureTypeForModal.slice(1)} Features for Product {currentCardForModal}</h2>
            <div>
              {AVAILABLE_FEATURES_LISTS[currentFeatureTypeForModal].map(feature => (
                <label key={feature} className="feature-checkbox-label">
                  <input
                    type="checkbox"
                    checked={selectedFeaturesInModal.has(feature)}
                    onChange={() => handleModalFeatureToggle(feature)}
                  />
                  {feature}
                </label>
              ))}
            </div>
            <div className="modal-actions">
              <button onClick={handleModalSelectAllFeatures} className="branded-alert-button">Select All</button>
              <button onClick={addSelectedFeaturesFromModal} className="branded-alert-button">Add Selected Features</button>
            </div>
          </div>
        </div>
      )}

      {sensitivityModalProductId !== null && (
          <div className="modal-overlay">
              <div className="modal-content" style={{maxWidth: '700px'}}>
                  <button onClick={closeSensitivityResultsModal} className="modal-close-btn">&times;</button>
                  <h2>Price Sensitivity Analysis for Product {sensitivityModalProductId}</h2>
                  <p>Base Product: {cardDataState[sensitivityModalProductId]?.product}</p>
                  <p>Current Price: ${cardDataState[sensitivityModalProductId]?.monthlyRate.toFixed(2)}</p>
                  
                  {!isAnalyzingSensitivity && !sensitivityResults && (
                      <button onClick={handlePriceSensitivityAnalysis} className="branded-alert-button" style={{marginTop:'10px'}}>
                          Run Analysis
                      </button>
                  )}
                  {isAnalyzingSensitivity && <div className="simulation-loading"><div className="spinner"></div>Analyzing...</div>}
                  {sensitivityResults && <SensitivityAnalysisDisplay results={sensitivityResults} />}
              </div>
          </div>
      )}

      {isProfilesModalOpen && (
          <div className="modal-overlay">
              <div className="modal-content" style={{maxWidth: '800px'}}>
                  <button onClick={() => setIsProfilesModalOpen(false)} className="modal-close-btn">&times;</button>
                  <h2>Product Profiles</h2>
                  {!productProfiles && <div className="simulation-loading"><div className="spinner"></div>Loading profiles...</div>}
                  {productProfiles && productProfiles.length === 0 && <p>No profiles generated or an error occurred.</p>}
                  {productProfiles && productProfiles.length > 0 && (
                      <ProductProfilesDisplay
                          profiles={productProfiles}
                          onProductSelect={handleProfileProductOptionClick}
                          selectedProductId={selectedProfileProductId}
                      />
                  )}
              </div>
          </div>
      )}
      {isMarketFactorsModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{maxWidth: '700px'}}>
            <button onClick={closeMarketFactorsModal} className="modal-close-btn">&times;</button>
            <h2>Adjust Market Factors & Base Take Rate</h2>
            
            <div>
              <label htmlFor="marketScenarioSelect">Select Scenario:</label>
              <select id="marketScenarioSelect" onChange={handleMarketScenarioChange} defaultValue="custom">
                <option value="custom">Custom</option>
                {Object.entries(marketScenarios).map(([key, scenario]) => (
                  <option key={key} value={key}>{scenario.name}</option>
                ))}
              </select>
            </div>
            <hr style={{margin: '15px 0'}}/>

            {Object.keys(marketFactors).map((factorKey) => {
              const key = factorKey as keyof MarketFactors;
              const definition = marketFactorDefinitions[key];
              return (
                <div key={key} style={{ marginBottom: '15px' }}>
                  <label htmlFor={key} style={{ fontWeight: 'bold' }}>
                    {definition?.title || key}
                    <button onClick={() => openMarketFactorInfoModal(key)} style={{ marginLeft: '10px', border: 'none', background: 'none', color: 'blue', cursor: 'pointer', fontSize: '0.9em' }}>(?)</button>
                  </label>
                  <p style={{fontSize: '0.85em', color: '#555', margin: '2px 0 5px 0'}}>{definition?.description.substring(0,100)}...</p>
                  <input
                    type="range"
                    id={key}
                    name={key}
                    min="0.5" // Example range, adjust as needed
                    max="1.5" // Example range
                    step="0.05" // Example step
                    value={marketFactors[key]}
                    onChange={(e) => handleMarketFactorChange(key, e.target.value)}
                    style={{ width: '80%', marginRight: '10px' }}
                  />
                  <span>{marketFactors[key].toFixed(2)}</span>
                </div>
              );
            })}
            <hr style={{margin: '15px 0'}}/>
             <div>
                <label htmlFor="baseTakeRate" style={{ fontWeight: 'bold' }}>Base Take Rate (Simulation Parameter)</label>
                 <p style={{fontSize: '0.85em', color: '#555', margin: '2px 0 5px 0'}}>Adjusts the baseline probability of a respondent choosing any product. Default is 0.15.</p>
                <input
                    type="number"
                    id="baseTakeRate"
                    name="baseTakeRate"
                    min="0.01"
                    max="1.0"
                    step="0.01"
                    value={baseTakeRateForModalDisplay}
                    onChange={(e) => setBaseTakeRateForModalDisplay(parseFloat(e.target.value))}
                    style={{ width: '100px', marginRight: '10px', padding: '5px' }}
                />
            </div>


            <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <button onClick={applyMarketFactors} className="branded-alert-button">Apply Factors</button>
            </div>
          </div>
        </div>
      )}

      {marketFactorInfoModalContent && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button onClick={() => setMarketFactorInfoModalContent(null)} className="modal-close-btn">&times;</button>
            <h2>{marketFactorInfoModalContent.title}</h2>
            <p>{marketFactorInfoModalContent.description}</p>
          </div>
        </div>
      )}
      {isReviewCoreProductsModalOpen && <ReviewCoreProductsModal onClose={() => setIsReviewCoreProductsModalOpen(false)} descriptions={coreProductDescriptionsData} />}
      {isReviewFeaturesModalOpen && <ReviewFeaturesModal onClose={() => setIsReviewFeaturesModalOpen(false)} descriptions={featureDescriptionsData} />}
      {isReviewVerticalsModalOpen && (
          <ReviewVerticalsModal 
              onClose={() => setIsReviewVerticalsModalOpen(false)} 
              descriptions={verticalDescriptionsData}
              availableVerticals={AVAILABLE_FEATURES_LISTS.vertical}
              selectedVertical={selectedVerticalForReview}
              onVerticalSelect={handleVerticalReviewSelect}
          />
      )}
      {isMarketSizingModalVisible && (
        <div className="modal-overlay" style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center', 
            backgroundColor: 'rgba(0,0,0,0.7)' 
        }}>
            <MarketSizingModal onClose={() => setIsMarketSizingModalVisible(false)} />
        </div>
      )}
      {showAboutModel && <ModelInfoModal onClose={() => setShowAboutModel(false)} />}


      {/* Custom Alert and Confirm Modals */}
      {customModal.visible && (
        <div className="modal-overlay">
          <div className="modal-content" style={{maxWidth: '450px'}}>
            {/* No close button for alerts/confirms, action needed */}
            <h2 className="branded-alert-title">{customModal.title}</h2>
            <p className="branded-alert-message">{customModal.message}</p>
            {customModal.isConfirm ? (
              <div className="branded-confirm-buttons">
                <button onClick={closeCustomModal} className="branded-confirm-button cancel">Cancel</button>
                <button onClick={handleCustomConfirm} className="branded-confirm-button">Confirm</button>
              </div>
            ) : (
              <div style={{textAlign: 'right'}}>
                <button onClick={closeCustomModal} className="branded-alert-button">OK</button>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}