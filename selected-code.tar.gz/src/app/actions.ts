'use server';

import type { 
  ProductSetupConfig, 
  ReportData, 
  ReportDataSegment,
  ReportType, 
  OutputType, 
  ProductProfileData,
  SensitivityPoint, 
  MarketFactors,
  SimulationOptions 
} from '@/lib/types';
import respondentProfile from "@/data/respondentProfile.json";
import drnRates from "@/data/drnRates.json";
import { DEMOGRAPHIC_SEGMENTS } from '@/lib/constants';
import fs from 'fs/promises';
import path from 'path';
import { performSimulation } from '@/lib/calculations';

// Interface definitions moved to top
interface RespondentUtility {
  Respondent_ID: string;
  Weight: number;
  Base_Reader?: number;
  Base_Streaming?: number;
  Base_AllAccess?: number;
  Base_Standalone?: number;
  Price_Linear?: number;
  Price_Squared?: number;
  [key: string]: any;
}

interface ModelParameter {
  Parameter: string;
  Value: number;
  Notes: string;
}

interface DemographicData {
  Respondent_ID: string;
  Gender?: string;
  Age_Group?: string;
  Political?: string;
  CNN_Access?: string;
  News_Subs?: number;
  Linear_TV?: string;
  Ad_Preference?: string;
  SG?: number;
  hAgeRecode?: number;
  SE?: number;
  SI?: number;
  S201?: number;
  S214?: number;
  TV5a06?: number;
  TV5b06?: number;
  N312?: number;
  N4_loop_13_N4?: number;
  [key: string]: any;
}

// Constants
const HHI_BANDS: Record<string, { name: string; lower: number; upper: number; width: number }> = {
  '1': { name: "Less than $35,000", lower: 0, upper: 34999, width: 34999 },
  '2': { name: "$35,000 to $49,999", lower: 35000, upper: 49999, width: 14999 },
  '3': { name: "$50,000 to $74,999", lower: 50000, upper: 74999, width: 24999 },
  '4': { name: "$75,000 to $99,999", lower: 75000, upper: 99999, width: 24999 },
  '5': { name: "$100,000 to $124,999", lower: 100000, upper: 124999, width: 24999 },
  '6': { name: "$125,000 to $149,999", lower: 125000, upper: 149999, width: 24999 },
  '7': { name: "$150,000 to $199,999", lower: 150000, upper: 199999, width: 49999 },
  '8': { name: "$200,000 to $299,999", lower: 200000, upper: 299999, width: 99999 },
  '9': { name: "$300,000 or more", lower: 300000, upper: Infinity, width: Infinity }
};

async function loadJsonData<T>(filename: string): Promise<T> {
  const filePath = path.join(process.cwd(), 'src', 'data', filename);
  try {
    const fileContents = await fs.readFile(filePath, 'utf8');
    return JSON.parse(fileContents) as T;
  } catch (error) {
    console.error(`Error loading ${filename}:`, error);
    throw new Error(`Could not load data file: ${filename}`);
  }
}

// SIMPLIFIED VERSION FOR DEBUGGING - now accepts 5 arguments
export async function runServerSimulation(
  activeProducts: ProductSetupConfig[],
  reportType: ReportType,
  outputType: OutputType,
  marketFactors: MarketFactors,
  simulationOptions: SimulationOptions
): Promise<ReportData | null> {
  console.log("actions.ts: runServerSimulation called with:");
  console.log("actions.ts: Product Configs:", JSON.stringify(activeProducts, null, 2));
  console.log("actions.ts: Report Type:", reportType);
  console.log("actions.ts: Output Type:", outputType);
  console.log("actions.ts: Market Factors:", JSON.stringify(marketFactors, null, 2));
  console.log("actions.ts: Simulation Options:", JSON.stringify(simulationOptions, null, 2));

  try {
    // Validate inputs
    if (!activeProducts || activeProducts.length === 0) {
      console.error('No active products provided');
      return null;
    }
    
    if (!reportType || !outputType) {
      console.error('Missing report type or output type');
      return null;
    }

    // Your existing simulation logic...
    const overallShare: number[] = activeProducts.map((_, index) => {
      return 10.0 + (index * 2);
    });
    
    const segmentShares: ReportDataSegment[] = DEMOGRAPHIC_SEGMENTS.map(segment => {
      return {
        segmentName: segment.group,
        shares: activeProducts.map((_, index) => {
          return 8.0 + (index * 1.5);
        })
      };
    });
    
    return {
      reportType,
      outputType,
      overallShare,
      segmentShares
    };
  } catch (error) {
    console.error('[actions.ts] Error in runServerSimulation:', error);
    throw error;
  }
}

export async function getProductProfile(productConfig: ProductSetupConfig): Promise<ProductProfileData | null> {
  try {
    const respondentUtilities = await loadJsonData<RespondentUtility[]>('respondentUtilities.json');
    const demographicsData = await loadJsonData<DemographicData[]>('demographics.json');
    const modelParametersList = await loadJsonData<ModelParameter[]>('modelParameters.json');
    const modelParams: Record<string, number> = {};
    modelParametersList.forEach(p => { modelParams[p.Parameter] = p.Value; });
    const TOTAL_TAM = modelParams['Total_TAM'] || 250000000;
    let productChoosersWeightedProbabilities: { demo: DemographicData, prob: number, weight: number }[] = [];
    let totalWeightedProbabilitySumForProduct = 0;

    for (const respUtil of respondentUtilities) { 
      let utility = 0;
      // Logic based on the updated ProductSetupConfig in types.ts (product: string)
      switch (productConfig.product) {
        case 'CNN Reader': utility += respUtil.Base_Reader || 0; break;
        case 'CNN Streaming': utility += respUtil.Base_Streaming || 0; break;
        case 'CNN All-Access': utility += respUtil.Base_AllAccess || 0; break;
        case 'CNN Standalone Vertical': utility += respUtil.Base_Standalone || 0; break;
        // Case 'None' or '' might not have a base utility, or it's handled by not adding base utility
      }
      const lnPrice = Math.log(productConfig.monthlyRate);
      utility += (respUtil.Price_Linear || 0) * lnPrice;
      if (respUtil.Price_Squared) utility += (respUtil.Price_Squared || 0) * lnPrice * lnPrice;
      const probability = 1 / (1 + Math.exp(-utility));
      const weight = respUtil.Weight || 1;
      const demo = demographicsData.find(d => d.Respondent_ID === respUtil.Respondent_ID);
      if (demo) {
        productChoosersWeightedProbabilities.push({ demo, prob: probability, weight });
        totalWeightedProbabilitySumForProduct += probability * weight;
      }
    } 
    const totalWeightSum = productChoosersWeightedProbabilities.reduce((sum, item) => sum + item.weight, 0);
    const overallChooserBase = totalWeightSum > 0 ? totalWeightedProbabilitySumForProduct / totalWeightSum * TOTAL_TAM : 0;
    
    // Changed type definition here
    const profileMetrics: Array<{ profile: string; variable: string; value: string }> = [];
    
    // Rest of the function remains the same
    profileMetrics.push({ profile: "Overall", variable: "Population Size (Est.)", value: overallChooserBase.toLocaleString(undefined, { maximumFractionDigits: 0 }) });
    profileMetrics.push({ profile: "Overall", variable: "TAM Proportion (%)", value: (overallChooserBase / TOTAL_TAM * 100).toFixed(1) });
    profileMetrics.push({ profile: "Overall", variable: "Est. Yr 1 Revenue ($)", value: (overallChooserBase * productConfig.monthlyRate * 12).toLocaleString(undefined, { maximumFractionDigits: 0, style: 'currency', currency: 'USD' }) });
    const calculateSegmentPercentage = (filterFn: (demo: DemographicData) => boolean, variableName: string) => {
      let segmentWeightedProbSum = 0;
      productChoosersWeightedProbabilities.forEach(item => {
        if (filterFn(item.demo)) { segmentWeightedProbSum += item.prob * item.weight; }
      });
      return totalWeightedProbabilitySumForProduct > 0 ? (segmentWeightedProbSum / totalWeightedProbabilitySumForProduct * 100).toFixed(1) : "0.0";
    };
    profileMetrics.push({ profile: "Gender", variable: "Male %", value: calculateSegmentPercentage(d => d.SG === 1, "Male") });
    profileMetrics.push({ profile: "Gender", variable: "Female %", value: calculateSegmentPercentage(d => d.SG === 2, "Female") });
    profileMetrics.push({ profile: "Gender", variable: "Other %", value: calculateSegmentPercentage(d => d.SG === 3, "Other") });
    profileMetrics.push({ profile: "Age", variable: "18-34 %", value: calculateSegmentPercentage(d => d.hAgeRecode === 1, "18-34") });
    profileMetrics.push({ profile: "Age", variable: "35-49 %", value: calculateSegmentPercentage(d => d.hAgeRecode === 2, "35-49") });
    profileMetrics.push({ profile: "Age", variable: "50-64 %", value: calculateSegmentPercentage(d => d.hAgeRecode === 3, "50-64") });
    profileMetrics.push({ profile: "Age", variable: "65+ %", value: calculateSegmentPercentage(d => d.hAgeRecode === 4, "65+") });
    const hhiWeightedValues: { siCode: number, weightedProb: number }[] = [];
    productChoosersWeightedProbabilities.forEach(item => { if (item.demo.SI !== undefined) { hhiWeightedValues.push({ siCode: item.demo.SI, weightedProb: item.prob * item.weight }); } });
    let medianHHIString = "N/A";
    if (hhiWeightedValues.length > 0) {
      const bandFrequencies: Record<string, number> = {};
      for (const bandCode in HHI_BANDS) { bandFrequencies[bandCode] = 0; }
      hhiWeightedValues.forEach(item => { bandFrequencies[item.siCode.toString()] += item.weightedProb; });
      const sortedBandCodes = Object.keys(HHI_BANDS).sort((a, b) => parseInt(a) - parseInt(b));
      const n = hhiWeightedValues.reduce((sum, item) => sum + item.weightedProb, 0);
      let cumulativeFrequency = 0;
      let medianBandCode = null;
      for (const bandCode of sortedBandCodes) {
        if (n / 2 <= cumulativeFrequency + bandFrequencies[bandCode]) { medianBandCode = bandCode; break; }
        cumulativeFrequency += bandFrequencies[bandCode];
      }
      if (medianBandCode) {
        const medianBandInfo = HHI_BANDS[medianBandCode];
        if (medianBandInfo.upper === Infinity) { medianHHIString = "$300,000+"; }
        else { const l = medianBandInfo.lower; const h = medianBandInfo.width; const f = bandFrequencies[medianBandCode]; const C = cumulativeFrequency; const medianValue = l + (h / f) * (n / 2 - C); medianHHIString = medianValue.toLocaleString(undefined, { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }); }
      }
    }
    profileMetrics.push({ profile: "Income", variable: "HHI (Median Est.)", value: medianHHIString });
    profileMetrics.push({ profile: "Education", variable: "College Grad+ %", value: calculateSegmentPercentage(d => d.SE === 1 || d.SE === 2, "College Grad+") });
    profileMetrics.push({ profile: "Political Affiliation", variable: "Democrat %", value: calculateSegmentPercentage(d => d.S201 === 1, "Democrat") });
    profileMetrics.push({ profile: "Political Affiliation", variable: "Republican %", value: calculateSegmentPercentage(d => d.S201 === 2, "Republican") });
    profileMetrics.push({ profile: "Political Affiliation", variable: "Independent %", value: calculateSegmentPercentage(d => d.S201 === 3, "Independent") });
    profileMetrics.push({ profile: "CNN Viewership", variable: "Regularly (Daily/Weekly) %", value: calculateSegmentPercentage(d => d.S214 === 1 || d.S214 === 2, "Regularly")});
    profileMetrics.push({ profile: "Linear TV", variable: "Has Linear TV Service %", value: calculateSegmentPercentage(d => d.TV5a06 === 1, "Has Linear TV") });
    
    // Create properly structured return object
    const productData: ProductProfileData = {
      [productConfig.product]: {
        verticals: productConfig.verticals || [],
        features: [...(productConfig.readerFeatures || []), ...(productConfig.streamingFeatures || [])],
        monthlyPrice: productConfig.monthlyRate,
        annualPrice: productConfig.monthlyRate * 12
      }
    };

    return productData;

  } catch (error) {
    console.error("Get Product Profile Error:", error);
    return null;
  }
}

export async function runPriceSensitivityAnalysis(
  productConfig: ProductSetupConfig,
  priceRange: { min: number; max: number; steps: number },
  marketFactors: MarketFactors,
  simulationOptions: SimulationOptions
): Promise<SensitivityPoint[]> {
  const results: SensitivityPoint[] = [];
  const { min, max, steps } = priceRange;
  const stepSize = steps > 1 ? (max - min) / (steps - 1) : 0;
  const baseRate = productConfig.monthlyRate;

  for (let i = 0; i < steps; i++) {
    const price = steps > 1 ? min + stepSize * i : min;
    const tempConfig: ProductSetupConfig = { ...productConfig, monthlyRate: price };

    const sim = await runServerSimulation(
      [tempConfig],
      'bundle',
      'percentage',
      marketFactors,
      simulationOptions
    );

    results.push({
      priceMultiplier: price / baseRate,
      takeRates: sim ? sim.overallShare : []
    });
  }
  return results;
}

export async function testServerAction(): Promise<{ message: string }> {
  console.log('Test server action called - this should appear in terminal');
  return { message: 'Server action works!' };
}
