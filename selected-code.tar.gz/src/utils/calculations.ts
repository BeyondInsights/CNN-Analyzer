// utils/calculations.ts

export const VALID_VERTICALS = [
  'D1_1', 'D1_2', 'D1_3', 'D1_4',
  'D2_1', 'D2_2', 'D2_3', 'D2_4',
  'B1', 'B2'
];

export function validateProductData(products: ProductSetupConfig[]): string[] {
  const errors: string[] = [];
  
  products.forEach((product, index) => {
    if (!product.product?.trim()) {
      errors.push(`Product ${index + 1}: Missing product name`);
    }
    
    if (!product.monthlyRate || product.monthlyRate <= 0) {
      errors.push(`${product.product}: Invalid monthly rate`);
    }
    
    const hasReaderFeatures = product.readerFeatures?.length > 0;
    const hasStreamingFeatures = product.streamingFeatures?.length > 0;
    
    if (!hasReaderFeatures && !hasStreamingFeatures) {
      errors.push(`${product.product}: No features selected`);
    }
    
    if (product.verticals) {
      product.verticals.forEach(v => {
        if (!VALID_VERTICALS.includes(v)) {
          errors.push(`${product.product}: Invalid vertical "${v}"`);
        }
      });
    }
  });
  
  return errors;
}

export function calculateUtility(product: ProductSetupConfig, p: RespondentParams): number {
  let u = 0;
  
  const features = p.features || p.all_features || {};
  
  // Handle reader features
  const readerFeatures = features.reader || features.readerFeatures || {};
  Object.entries(readerFeatures).forEach(([f, val]) => {
    if (product.readerFeatures?.includes(f)) u += val;
  });

  // Handle streaming features
  const streamingFeatures = features.streaming || features.streamingFeatures || {};
  Object.entries(streamingFeatures).forEach(([f, val]) => {
    if (product.streamingFeatures?.includes(f)) u += val;
  });
  
  return u;
}