// File: src/components/MarketFactorsModal.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { Dialog } from '@headlessui/react';
import { X } from 'lucide-react';
import type { MarketFactors, MarketFactorSettings } from '@/lib/types';
import { auth } from '@/lib/firebaseClient';

interface MarketFactorsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyFactors: (settings: MarketFactorSettings) => void;
  currentFactors: MarketFactors;
}

export default function MarketFactorsModal({ 
  isOpen, 
  onClose, 
  onApplyFactors, 
  currentFactors 
}: MarketFactorsModalProps) {
  // Initialize settings from currentFactors or use defaults
  const [settings, setSettings] = useState<MarketFactorSettings>({
    scenario: 'realistic',
    awareness: currentFactors?.awareness || 70,
    distribution: currentFactors?.distribution || 85,
    competitive: currentFactors?.competitive || 90,
    marketing: currentFactors?.marketing || 80,
    yearOneAdoption: currentFactors?.yearOneAdoption || 65,
    enablePriceSensitivity: currentFactors?.enablePriceSensitivity || false,
    lowPriceMultiplier: currentFactors?.lowPriceMultiplier || 1.3,
    highPriceMultiplier: currentFactors?.highPriceMultiplier || 0.8,
    priceThreshold: currentFactors?.priceThreshold || 12
  });

  // Update settings when currentFactors changes
  useEffect(() => {
    if (currentFactors) {
      setSettings(prev => ({
        ...prev,
        awareness: currentFactors.awareness ?? prev.awareness,
        distribution: currentFactors.distribution ?? prev.distribution,
        competitive: currentFactors.competitive ?? prev.competitive,
        marketing: currentFactors.marketing ?? prev.marketing,
        yearOneAdoption: currentFactors.yearOneAdoption ?? prev.yearOneAdoption,
        enablePriceSensitivity: currentFactors.enablePriceSensitivity ?? prev.enablePriceSensitivity,
        lowPriceMultiplier: currentFactors.lowPriceMultiplier ?? prev.lowPriceMultiplier,
        highPriceMultiplier: currentFactors.highPriceMultiplier ?? prev.highPriceMultiplier,
        priceThreshold: currentFactors.priceThreshold ?? prev.priceThreshold
      }));
    }
  }, [currentFactors]);

  // Auth state listener
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUserId(user?.uid || null);
    });

    // Cleanup subscription on unmount
    return () => unsubscribe();
  }, []);

  return (
    <Dialog open={isOpen} onClose={onClose} className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4">
        <Dialog.Panel className="w-full max-w-md bg-white p-6 rounded-2xl shadow-xl">
          <div className="flex justify-between items-center mb-4">
            <Dialog.Title className="text-lg font-semibold">Market & Time Adjustments</Dialog.Title>
            <button onClick={onClose}><X size={20} /></button>
          </div>

          <div className="space-y-4">
            {/* Core Market Factors */}
            <div>
              <label className="block text-sm font-medium">
                Market Awareness <span className="text-gray-500">({settings.awareness}%)</span>
              </label>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={settings.awareness}
                onChange={e => setSettings({ ...settings, awareness: Number(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium">
                Distribution Reach <span className="text-gray-500">({settings.distribution}%)</span>
              </label>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={settings.distribution}
                onChange={e => setSettings({ ...settings, distribution: Number(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium">
                Competitive Factor <span className="text-gray-500">({settings.competitive}%)</span>
              </label>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={settings.competition}
                onChange={e => setSettings({ ...settings, competitive: Number(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium">
                Marketing Effectiveness <span className="text-gray-500">({settings.marketing}%)</span>
              </label>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={settings.marketing}
                onChange={e => setSettings({ ...settings, marketing: Number(e.target.value) })}
                className="w-full"
              />
            </div>

            {/* Year One Adoption */}
            <div className="border-t pt-4">
              <label className="inline-flex items-center">
                <input
                  type="checkbox"
                  checked={settings.enableYearOne}
                  onChange={e => setSettings({ ...settings, enableYearOne: e.target.checked })}
                  className="mr-2"
                />
                Apply Year 1 Adoption Curve
              </label>
              {settings.enableYearOne && (
                <div className="mt-3 space-y-2">
                  <label className="block text-sm font-medium">
                    Year One (% of steady state):
                  </label>
                  <input
                    type="range"
                    min={20}
                    max={100}
                    step={5}
                    value={settings.yearOnePercent}
                    onChange={e => setSettings({ ...settings, yearOnePercent: Number(e.target.value) })}
                    className="w-full"
                  />
                  <div className="flex space-x-2 mt-1 text-xs">
                    {[40, 65, 85].map(p => (
                      <button
                        key={p}
                        onClick={() => setSettings({ ...settings, yearOnePercent: p })}
                        className="px-2 py-1 bg-gray-100 rounded"
                      >{p}%</button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Tiered Price Sensitivity */}
            <div className="border-t pt-4">
              <label className="inline-flex items-center">
                <input
                  type="checkbox"
                  checked={settings.enableTieredPricing}
                  onChange={e => setSettings({ ...settings, enableTieredPricing: e.target.checked })}
                  className="mr-2"
                />
                Enable Tiered Price Sensitivity
              </label>
              {settings.enableTieredPricing && (
                <div className="mt-3 space-y-3">
                  <div>
                    <label className="block text-sm font-medium">Threshold Price ($)</label>
                    <input
                      type="number"
                      min={0}
                      value={settings.priceThreshold}
                      onChange={e => setSettings({ ...settings, priceThreshold: Number(e.target.value) })}
                      className="w-full border rounded p-1" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium">Low Price Multiplier</label>
                    <input
                      type="number"
                      step={0.1}
                      value={settings.lowPriceMultiplier}
                      onChange={e => setSettings({ ...settings, lowPriceMultiplier: Number(e.target.value) })}
                      className="w-full border rounded p-1"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium">High Price Multiplier</label>
                    <input
                      type="number"
                      step={0.1}
                      value={settings.highPriceMultiplier}
                      onChange={e => setSettings({ ...settings, highPriceMultiplier: Number(e.target.value) })}
                      className="w-full border rounded p-1"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end space-x-2 mt-4">
              <button
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 rounded-md"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onApplyFactors(settings);
                  onClose();
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-md"
              >
                Apply Factors
              </button>
            </div>
          </div>
        </Dialog.Panel>
      </div>
    </Dialog>
  );
}
