'use client';

import React, { useState, useEffect } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { firestore } from '@/lib/firebaseClient';
import { computeTakeRates } from '@/lib/calculations';
import ModelInfoModal from '@/components/ModelInfoModal';
import MarketFactorsModal from '@/components/MarketFactorsModal';
import type { RespondentWithParams, ProductSetupConfig, MarketFactorSettings, MarketFactors, SimulationOptions, SimulationResults } from '@/lib/types';

export default function SimulatorSection() {
  const [loading, setLoading] = useState(false);
  const [respondents, setRespondents] = useState<RespondentWithParams[]>([]);
  const [results, setResults] = useState<SimulationResults | null>(null);
  const [showMarketFactors, setShowMarketFactors] = useState(false);
  const [showAboutModel, setShowAboutModel] = useState(false);
  
  // Product configurations
  const [products, setProducts] = useState<ProductSetupConfig[]>([
    {
      product: "CNN Reader",
      monthlyRate: 9.99,
      verticals: [],
      readerFeatures: [],
      streamingFeatures: [],
      isActive: true,
      pricingType: 'monthly',
      discount: 'none'
    },
    {
      product: "CNN Streaming",
      monthlyRate: 14.99,
      verticals: [],
      readerFeatures: [],
      streamingFeatures: [],
      isActive: true,
      pricingType: 'monthly',
      discount: 'none'
    },
    {
      product: "CNN All-Access",
      monthlyRate: 19.99,
      verticals: [],
      readerFeatures: [],
      streamingFeatures: [],
      isActive: true,
      pricingType: 'monthly',
      discount: 'none'
    }
  ]);

  // Simulation options
  const [simulationOptions, setSimulationOptions] = useState<SimulationOptions>({
    takeThreshold: 0.15,
    drnFactor: 1.0,
    allocationMethod: 'proportional',
    enablePriceTiers: false,
    priceThreshold: 12,
    lowPriceMultiplier: 1.3,
    highPriceMultiplier: 0.8
  });

  // Market factors
  const [marketFactors, setMarketFactors] = useState<MarketFactors>({
    baseConversion: 0.5,
    awareness: 70,
    distribution: 85,
    competitive: 90,
    marketing: 80,
    yearOneAdoption: 65
  });

  // Simulation state
  const [simulationState, setSimulationState] = useState<'idle' | 'validating' | 'running' | 'complete' | 'error'>('idle');

  // Load respondent data on mount
  useEffect(() => {
    loadRespondentData();
  }, []);

  const loadRespondentData = async () => {
    try {
      setLoading(true);
      const snapshot = await getDocs(collection(firestore, 'userProfiles'));
      
      if (snapshot.empty) {
        console.warn('No respondent profiles found');
        setRespondents([]);
        return;
      }

      const respondentData: RespondentWithParams[] = snapshot.docs.map(doc => {
        const data = doc.data();
        
        // Determine age group
        const ageGroup = data.Age_18_34 ? "18-34" : 
                        data.Age_35_54 ? "35-54" : 
                        data.Age_55_74 ? "55-74" : "Unknown";
        
        return {
          respondentId: data.Respondent_ID,
          weight: data.Weight || 1,
          drn: data.DRN_Composite || data.DRN_Base || 0.85,
          gender: data.Gender || "Unknown",
          ageGroup: ageGroup,
          individualParams: {
            base: data.base || {},
            price: data.price || { linear: -1.08, squared: -0.007 },
            verticals: data.verticals || {},
            verticalCount: data.verticalCount || {},
            readerFeatures: data.all_features?.reader || data.features?.reader || {},
            streamingFeatures: data.all_features?.streaming || data.features?.streaming || {}
          }
        };
      });
      
      setRespondents(respondentData);
      console.log(`Loaded ${respondentData.length} respondent profiles`);
    } catch (error) {
      console.error('Error loading respondent data:', error);
    } finally {
      setLoading(false);
    }
  };

  const runSimulation = async () => {
    try {
      setSimulationState('validating');
      
      // Log product configuration
      console.log('=== PRODUCT CONFIGURATION ===');
      products.forEach((p, i) => {
        console.log(`Product ${i + 1}: ${p.product}`);
        console.log(`  Monthly Rate: $${p.monthlyRate}`);
        console.log(`  Verticals: ${p.verticals.join(', ') || 'None'}`);
        console.log(`  Reader Features: ${p.readerFeatures.join(', ') || 'None'}`);
        console.log(`  Streaming Features: ${p.streamingFeatures.join(', ') || 'None'}`);
        console.log(`  Active: ${p.isActive}`);
      });

      const errors = validateProductData(products.filter(p => p.isActive));
      if (errors.length > 0) {
        throw new Error(errors.join('\n'));
      }
      
      setSimulationState('running');
      debugDataFlow('Starting Simulation', { products, respondents: respondents.slice(0, 3) });
      
      const results = computeTakeRates(respondents, products, simulationOptions, marketFactors);
      debugDataFlow('Simulation Results', results);
      
      setSimulationState('complete');
      setResults(results);
      
    } catch (error) {
      setSimulationState('error');
      console.error('Simulation failed:', error);
      alert(`Simulation failed: ${error.message}`);
    }
  };

  const handleMarketFactorsApply = (settings: MarketFactorSettings) => {
    const factors: MarketFactors = {
      baseConversion: 0.5,
      awareness: settings.awareness,
      distribution: settings.distribution,
      competitive: settings.competitive,
      marketing: settings.marketing,
      yearOneAdoption: settings.yearOneAdoption,
      ...(settings.enablePriceSensitivity && {
        enablePriceSensitivity: true,
        lowPriceMultiplier: settings.lowPriceMultiplier,
        highPriceMultiplier: settings.highPriceMultiplier,
        priceThreshold: settings.priceThreshold
      })
    };
    
    setMarketFactors(factors);
  };

  return (
    <section id="simulator" className="py-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                CNN Subscription Bundle Simulator
              </h1>
              <p className="text-gray-600 mt-2">
                {respondents.length > 0 
                  ? `Loaded ${respondents.length} respondent profiles`
                  : 'Loading respondent data...'}
              </p>
            </div>
            <div className="flex gap-4">
              <button
                onClick={() => setShowMarketFactors(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Market Factors
              </button>
              <button
                onClick={() => setShowAboutModel(true)}
                className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
              >
                About Model
              </button>
            </div>
          </div>
        </div>

        {/* Product Configuration */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Product Configuration</h2>
          <div className="space-y-4">
            {products.map((product, index) => (
              <div key={product.product} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">{product.product}</h3>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={product.isActive}
                      onChange={(e) => {
                        const updated = [...products];
                        updated[index].isActive = e.target.checked;
                        setProducts(updated);
                      }}
                    />
                    <span>Active</span>
                  </label>
                </div>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2">
                    <span>Monthly Price: $</span>
                    <input
                      type="number"
                      value={product.monthlyRate}
                      onChange={(e) => {
                        const updated = [...products];
                        updated[index].monthlyRate = parseFloat(e.target.value) || 0;
                        setProducts(updated);
                      }}
                      className="px-2 py-1 border rounded w-24"
                      step="0.01"
                      min="0"
                    />
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Simulation Options */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Simulation Options</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Take Rate Threshold: {(simulationOptions.takeThreshold * 100).toFixed(0)}%
              </label>
              <input
                type="range"
                min="5"
                max="30"
                value={simulationOptions.takeThreshold * 100}
                onChange={(e) => setSimulationOptions({
                  ...simulationOptions,
                  takeThreshold: parseInt(e.target.value) / 100
                })}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">
                Allocation Method
              </label>
              <select
                value={simulationOptions.allocationMethod}
                onChange={(e) => setSimulationOptions({
                  ...simulationOptions,
                  allocationMethod: e.target.value as 'proportional' | 'winner-takes-all'
                })}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="proportional">Proportional</option>
                <option value="winner-takes-all">Winner Takes All</option>
              </select>
            </div>
          </div>

          {simulationOptions.enablePriceTiers && (
            <div className="mt-4 p-4 border rounded">
              <h4 className="font-medium mb-2">Price Sensitivity Tiers</h4>
              
              <label className="block mb-2">
                Threshold: ${simulationOptions.priceThreshold || 12}
                <input
                  type="range"
                  min="5"
                  max="20"
                  value={simulationOptions.priceThreshold || 12}
                  onChange={(e) => setSimulationOptions({
                    ...simulationOptions,
                    priceThreshold: Number(e.target.value)
                  })}
                  className="w-full"
                />
              </label>
              
              <label className="block mb-2">
                Low Price Multiplier: {simulationOptions.lowPriceMultiplier || 1.3}x
                <input
                  type="range"
                  min="1"
                  max="2"
                  step="0.1"
                  value={simulationOptions.lowPriceMultiplier || 1.3}
                  onChange={(e) => setSimulationOptions({
                    ...simulationOptions,
                    lowPriceMultiplier: Number(e.target.value)
                  })}
                  className="w-full"
                />
              </label>
            </div>
          )}
        </div>

        {/* Run Simulation Button */}
        <div className="text-center mb-6">
          <button
            onClick={runSimulation}
            disabled={loading || respondents.length === 0}
            className="px-8 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {loading ? 'Running...' : 'Run Simulation'}
          </button>
        </div>

        {/* Results */}
        {results && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Results</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2">Product</th>
                    <th className="text-right py-2">Take Rate</th>
                    <th className="text-right py-2">Subscribers</th>
                    <th className="text-right py-2">Annual Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  {results.takeRates?.map((rate: any) => (
                    <tr key={rate.productName} className="border-b">
                      <td className="py-2">{rate.productName}</td>
                      <td className="text-right font-semibold">{(rate.adjustedTakeRate || rate.takeRate).toFixed(1)}%</td>
                      <td className="text-right">{rate.subscribers.toLocaleString()}</td>
                      <td className="text-right">${(rate.revenue / 1000000).toFixed(1)}M</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Modals */}
        <MarketFactorsModal
          isOpen={showMarketFactors}
          onClose={() => setShowMarketFactors(false)}
          onApplyFactors={handleMarketFactorsApply}
          currentFactors={marketFactors}
        />

        <ModelInfoModal
          isOpen={showAboutModel}
          onClose={() => setShowAboutModel(false)}
        />
      </div>
    </section>
  );
}