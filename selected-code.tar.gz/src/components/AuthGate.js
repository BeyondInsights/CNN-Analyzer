// File: src/components/AuthGate.js
'use client';

import { useState, useEffect } from 'react';
import netlifyIdentity from 'netlify-identity-widget';
import PasswordProtect from '@/components/PasswordProtect';

/**
 * AuthGate wraps its children and requires password protection + Netlify Identity login.
 * - Uses PasswordProtect first to guard entry.
 * - Then initializes Netlify Identity for full auth.
 * - Can pause site via NEXT_PUBLIC_PAUSE env var or bypass in dev.
 */
export default function AuthGate({ children }) {
  // Full site pause flag
  if (process.env.NEXT_PUBLIC_PAUSE === 'true') {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-gray-100">
        <h1 className="text-2xl font-bold">Site is temporarily paused.</h1>
      </div>
    );
  }

  // Bypass all auth in development for local testing
  if (process.env.NODE_ENV === 'development') {
    return <>{children}</>;
  }

  // First, require password protection
  const [passwordAuthDone, setPasswordAuthDone] = useState(false);
  if (!passwordAuthDone) {
    return <PasswordProtect onAuthenticated={() => setPasswordAuthDone(true)} />;
  }

  // After password auth, proceed with Netlify Identity
  const [user, setUser] = useState(null);
  const [initDone, setInitDone] = useState(false);

  useEffect(() => {
    const identityUrl =
      process.env.NEXT_PUBLIC_IDENTITY_URL ||
      `${window.location.origin}/.netlify/identity`;
    netlifyIdentity.init({ APIUrl: identityUrl });

    // Set current user if already logged in
    const currentUser = netlifyIdentity.currentUser();
    setUser(currentUser);
    setInitDone(true);

    // Listen for login/logout events
    netlifyIdentity.on('login', (usr) => {
      setUser(usr);
      netlifyIdentity.close();
    });
    netlifyIdentity.on('logout', () => setUser(null));

    return () => {
      netlifyIdentity.off('login');
      netlifyIdentity.off('logout');
    };
  }, []);

  if (!initDone) {
    return <div className="p-6 text-center">Loading authentication…</div>;
  }

  if (!user) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
        <button
          onClick={() => netlifyIdentity.open()}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg"
        >
          Login or Sign Up
        </button>
      </div>
    );
  }

  // Authenticated: render app
  return <>{children}</>;
}
