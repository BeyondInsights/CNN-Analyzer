'use client';

import React, { useEffect, useState, useCallback } from "react";
import { pricingTable, type BaseProductName } from "../../lib/pricingTable";
import { useAppContext } from "../../contexts/AppContext";
import type { ProductSetupConfig, PricingType as ProductPricingType, DiscountType as ProductDiscountType } from '../../lib/types'; // Renamed to avoid conflict
import { Slider } from "@/components/ui/slider"; 
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"; // Added this import
import { AVAILABLE_FEATURES, PRODUCT_TYPES } from '@/lib/constants'; // Added PRODUCT_TYPES import

// Helper function to convert ProductSetupConfig product name to BaseProductName for pricingTable
const toBaseProductName = (name: ProductSetupConfig['product'] | ""): BaseProductName | "" => {
  if (name === "CNN Standalone Vertical") return "Standalone Vertical";
  if (name === "" || name === "CNN Reader" || name === "CNN Streaming" || name === "CNN All-Access") return name;
  return ""; // Fallback for unknown names
};

// Helper function to convert BaseProductName from pricingTable back to ProductSetupConfig product name
const toProductSetupConfigName = (name: BaseProductName | ""): ProductSetupConfig['product'] => {
  if (name === "Standalone Vertical") return "CNN Standalone Vertical";
  return name; // Other names are consistent
};

export default function ProductCard({ productConfig }: { productConfig: ProductSetupConfig }) {
  const { 
    featuresList, 
    pricingConfig, 
    uiTemplates, 
    updateProductSetupConfig,
    openFeatureModal 
  } = useAppContext();
  
  const slot = productConfig.id;

  // Local state for UI interaction, initialized from productConfig prop
  const [currentBaseProduct, setCurrentBaseProduct] = useState<BaseProductName | "">(toBaseProductName(productConfig.product));
  const [currentRate, setCurrentRate] = useState<number>(productConfig.monthlyRate);
  const [currentPricingType, setCurrentPricingType] = useState<ProductPricingType>(productConfig.pricingType || '');
  const [currentDiscount, setCurrentDiscount] = useState<ProductDiscountType>(productConfig.discount || '');
  const [isExcluded, setIsExcluded] = useState<boolean>(productConfig.excluded);

  const [currentPricingRange, setCurrentPricingRange] = useState<{ min: number; max: number; default: number }>(() => {
    const baseName = toBaseProductName(productConfig.product);
    if (baseName) {
      const vCount = Math.min((productConfig.selectedVerticals || []).length, 3) as 0 | 1 | 2 | 3;
      return pricingTable[baseName]?.[vCount] || { min: pricingConfig.minPrice, max: pricingConfig.maxPrice, default: pricingConfig.minPrice };
    }
    return { min: pricingConfig.minPrice, max: pricingConfig.maxPrice, default: pricingConfig.minPrice };
  });

  // Update local state if productConfig prop changes (e.g., from context undo/redo, load preset)
  useEffect(() => {
    const baseNameFromProp = toBaseProductName(productConfig.product);
    setCurrentBaseProduct(baseNameFromProp);
    setCurrentRate(productConfig.monthlyRate);
    setCurrentPricingType(productConfig.pricingType || '');
    setCurrentDiscount(productConfig.discount || '');
    setIsExcluded(productConfig.excluded);

    if (baseNameFromProp) {
      const vCount = Math.min((productConfig.selectedVerticals || []).length, 3) as 0 | 1 | 2 | 3;
      const range = pricingTable[baseNameFromProp]?.[vCount];
      if (range) {
        setCurrentPricingRange(range);
        // Clamp currentRate if it's outside the new range from props
        if (productConfig.monthlyRate < range.min || productConfig.monthlyRate > range.max) {
            // This could happen if context updates with an out-of-range value.
            // We might want to call updateProductSetupConfig here to correct it in the context too.
            setCurrentRate(Math.max(range.min, Math.min(range.max, productConfig.monthlyRate)));
        }
      } else {
        setCurrentPricingRange({ min: pricingConfig.minPrice, max: pricingConfig.maxPrice, default: pricingConfig.minPrice });
      }
    } else {
      setCurrentPricingRange({ min: pricingConfig.minPrice, max: pricingConfig.maxPrice, default: pricingConfig.minPrice });
    }
  }, [productConfig, pricingConfig]);

  // Effect to recalculate pricing range when local baseProduct or selectedVerticals (from context) change
  useEffect(() => {
    if (currentBaseProduct) {
      const vCount = Math.min((productConfig.selectedVerticals || []).length, 3) as 0 | 1 | 2 | 3; // Verticals from prop
      const range = pricingTable[currentBaseProduct]?.[vCount];
      if (range) {
        setCurrentPricingRange(range);
        if (currentRate < range.min || currentRate > range.max) {
          const newClampedRate = Math.max(range.min, Math.min(range.max, currentRate));
          setCurrentRate(newClampedRate);
          updateProductSetupConfig(slot, { monthlyRate: newClampedRate });
        }
      }
    } else {
      setCurrentPricingRange({ min: pricingConfig.minPrice, max: pricingConfig.maxPrice, default: pricingConfig.minPrice });
      // If no base product, reset rate to a general default if it was tied to a specific product range
       if (currentRate !== pricingConfig.minPrice) { // Example reset logic
           setCurrentRate(pricingConfig.minPrice);
           updateProductSetupConfig(slot, { monthlyRate: pricingConfig.minPrice });
       }
    }
  }, [currentBaseProduct, productConfig.selectedVerticals, pricingConfig, slot, updateProductSetupConfig, currentRate]);

  const handleBaseProductChange = (value: BaseProductName | "") => {
    setCurrentBaseProduct(value);
    const productForContext = toProductSetupConfigName(value);
    let newRate = currentPricingRange.default; // Default to new range's default
    if (value) {
        const vCount = Math.min((productConfig.selectedVerticals || []).length, 3) as 0 | 1 | 2 | 3;
        const range = pricingTable[value]?.[vCount];
        if(range) newRate = range.default;
    }
    setCurrentRate(newRate);
    updateProductSetupConfig(slot, { product: productForContext, monthlyRate: newRate });
  };

  const handleSliderChange = (value: number[]) => {
    setCurrentRate(value[0]);
    updateProductSetupConfig(slot, { monthlyRate: value[0] });
  };

  const handlePricingTypeBtnClick = (type: ProductPricingType) => {
    setCurrentPricingType(type);
    const newDiscount = type !== 'both' ? '' : currentDiscount;
    if (type !== 'both') setCurrentDiscount('');
    updateProductSetupConfig(slot, { pricingType: type, discount: newDiscount });
  };
  
  const handleDiscountRadioChange = (value: ProductDiscountType) => {
    setCurrentDiscount(value);
    updateProductSetupConfig(slot, { discount: value });
  };

  const handleExcludedChange = (checked: boolean) => {
    setIsExcluded(checked);
    updateProductSetupConfig(slot, { excluded: checked });
  };
  
  const headerText = productConfig.product || `PRODUCT ${slot}`;
  const cardBgColor = isExcluded ? 'bg-gray-100' : 'bg-white';
  const headerUiColor = uiTemplates.cardHeaderColor || 'bg-red-600'; // Default to red if not specified

  return (
    <Card className={`w-[320px] flex-shrink-0 shadow-lg rounded-lg border flex flex-col ${cardBgColor} ${isExcluded ? 'opacity-60' : ''}`}>
      <CardHeader className={`flex flex-row items-center justify-center p-3 rounded-t-lg text-white ${isExcluded ? 'bg-gray-400' : headerUiColor}`}>
        <CardTitle className="text-md font-semibold truncate" title={headerText}>{headerText}</CardTitle>
      </CardHeader>
      <CardContent className="p-3 space-y-3 flex-grow">
        <Select value={currentBaseProduct} onValueChange={handleBaseProductChange} disabled={isExcluded}>
          <SelectTrigger><SelectValue placeholder="Select Base Product" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="">Select Base Product</SelectItem>
            {PRODUCT_TYPES.map(ptype => (
              <SelectItem key={ptype} value={toBaseProductName(ptype)}>
                {ptype}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {(currentBaseProduct === 'CNN Reader' || currentBaseProduct === 'CNN All-Access') && (
          <div>
            <Label className="text-xs">Reader Features ({productConfig.selectedReaderFeatures?.length || 0} selected)</Label>
            <Button variant="outline" size="sm" className="w-full mt-1 text-xs" onClick={() => openFeatureModal(slot, 'reader')} disabled={isExcluded || !currentBaseProduct}>+ Add Features</Button>
          </div>
        )}
        {(currentBaseProduct === 'CNN Streaming' || currentBaseProduct === 'CNN All-Access') && (
           <div>
            <Label className="text-xs">Streaming Features ({productConfig.selectedStreamingFeatures?.length || 0} selected)</Label>
            <Button variant="outline" size="sm" className="w-full mt-1 text-xs" onClick={() => openFeatureModal(slot, 'streaming')} disabled={isExcluded || !currentBaseProduct}>+ Add Features</Button>
          </div>
        )}
        <div>
          <Label className="text-xs">Verticals ({productConfig.selectedVerticals?.length || 0} selected)</Label>
          <Button variant="outline" size="sm" className="w-full mt-1 text-xs" onClick={() => openFeatureModal(slot, 'vertical')} disabled={isExcluded || !currentBaseProduct}>+ Add Verticals</Button>
        </div>

        <div className="pt-2">
          <Label className="text-sm font-medium">Configure Pricing</Label>
          <div className="flex gap-1 mt-1 mb-2">
            {(['monthly', 'annual', 'both'] as const).map(type => (
              <Button key={type} variant={currentPricingType === type ? 'default' : 'outline'} size="sm" onClick={() => handlePricingTypeBtnClick(type)} className="flex-1 capitalize text-xs h-8" disabled={isExcluded || !currentBaseProduct}>{type}</Button>
            ))}
          </div>

          {currentPricingType === 'both' && (
            <Card className="bg-muted/30 p-2 my-2">
              <CardContent className="p-0">
                <Label className="text-xs font-semibold mb-1 block">Discount for Annual</Label>
                <RadioGroup value={currentDiscount} onValueChange={handleDiscountRadioChange} className="mt-1 space-y-1">
                  {(['', 'free', '30', '50'] as ProductDiscountType[]).map(opt => (
                    <div key={opt || 'none'} className="flex items-center space-x-2">
                      <RadioGroupItem value={opt} id={`${slot}-discount-${opt || 'none'}`} disabled={isExcluded || !currentBaseProduct} />
                      <Label htmlFor={`${slot}-discount-${opt || 'none'}`} className="text-xs font-normal">
                        {opt === '' ? 'None' : opt === 'free' ? '3 Months Free' : `${opt}% Off`}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>
          )}

          <Label htmlFor={`slider-${slot}`} className="text-xs">Monthly Rate: ${currentRate.toFixed(2)}</Label>
          <Slider
            id={`slider-${slot}`}
            value={[currentRate]}
            min={currentPricingRange.min}
            max={currentPricingRange.max}
            step={0.50} // Or make dynamic
            onValueChange={handleSliderChange}
            disabled={isExcluded || !currentBaseProduct}
            className="my-2"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>${currentPricingRange.min.toFixed(2)}</span>
            <span>${currentPricingRange.max.toFixed(2)}</span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">Inferred Annual: ${(currentRate * 12).toFixed(2)}</div>
        </div>
      </CardContent>
      <CardFooter className="p-3 mt-auto">
        <Label htmlFor={`excluded-${slot}-${productConfig.id}`} className="flex items-center space-x-2 text-xs cursor-pointer">
          <Checkbox id={`excluded-${slot}-${productConfig.id}`} checked={isExcluded} onCheckedChange={handleExcludedChange} />
          <span>Exclude from Simulation</span>
        </Label>
      </CardFooter>
        {isExcluded && (
            <div className="absolute inset-0 bg-slate-200/70 flex items-center justify-center rounded-lg">
                <div className="text-red-600 font-bold text-xl transform -rotate-15 border-4 border-red-600 p-2 whitespace-nowrap bg-white/80">
                    EXCLUDED FROM SIMULATION
                </div>
            </div>
        )}
    </Card>
  );
}
