// File: src/components/ModelInfoModal.tsx
'use client';

import React, { Fragment } from 'react';
import { Dialog, Transition, Tab } from '@headlessui/react';
import { X } from 'lucide-react';

interface ModelInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ModelInfoModal: React.FC<ModelInfoModalProps> = ({ isOpen, onClose }) => {
  const tabs = ['Model Excellence', 'Advanced Methodology', 'Diagnostics', 'Industry Standards'];
  if (!isOpen) {
    return null;
  }

  return (
    <Transition.Root show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm" />
        </Transition.Child>
        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-3xl transform overflow-hidden rounded-2xl bg-white p-6 text-left shadow-xl transition-all">
                <div className="flex justify-between items-center mb-4">
                  <Dialog.Title as="h2" className="text-xl font-semibold">About the Model</Dialog.Title>
                  <button onClick={onClose} className="p-1">
                    <X size={20} />
                  </button>
                </div>
                <Tab.Group>
                  <Tab.List className="flex space-x-4 border-b pb-2">
                    {tabs.map(tab => (
                      <Tab
                        key={tab}
                        className={({ selected }) =>
                          `px-4 py-2 font-medium ${selected ? 'border-b-2 border-red-600 text-red-600' : 'text-gray-500'}`
                        }
                      >
                        {tab}
                      </Tab>
                    ))}
                  </Tab.List>
                  <Tab.Panels className="mt-4">
                    <Tab.Panel>
                      <ul className="space-y-2 list-disc pl-5">
                        <li><strong>2,158 individual-level models:</strong> No averages—each respondent modeled separately.</li>
                        <li><strong>Deep Residual Networks (DRN):</strong> Task-based conversion propensity for precision.</li>
                        <li><strong>Vertical bridging:</strong> Solved 40% missing data, enabling richer insights.</li>
                        <li><strong>Calibration:</strong> Expanded from 5 to 31 features, 6× coverage beyond industry norm.</li>
                      </ul>
                    </Tab.Panel>
                    <Tab.Panel>
                      <ul className="space-y-2 list-disc pl-5">
                        <li><strong>Hierarchical Bayesian framework:</strong> Captures both population and individual variability.</li>
                        <li><strong>Log-linear & quadratic pricing:</strong> Reflects real-world elasticity, proportional impact across tiers.</li>
                        <li><strong>Scenario embeddings:</strong> Contextual DRN adjusts for competitive & bundle tasks.</li>
                        <li><strong>Payment term integration:</strong> Models monthly vs annual choices based on discount thresholds.</li>
                      </ul>
                    </Tab.Panel>
                    <Tab.Panel>
                      <ul className="space-y-2 list-disc pl-5">
                        <li><strong>Rhat = 1.008:</strong> Convergence well within 1.01 threshold.</li>
                        <li><strong>Effective Sample Size &gt;1,000:</strong> Robust parameter estimates.</li>
                        <li><strong>No divergent transitions:</strong> Stable, reliable posterior draws.</li>
                        <li><strong>120,848 observations:</strong> 2,158 respondents × 14 tasks × 4 options.</li>
                      </ul>
                    </Tab.Panel>
                    <Tab.Panel>
                      <table className="w-full table-auto text-sm">
                        <thead>
                          <tr>
                            <th className="border px-2 py-1">Feature</th>
                            <th className="border px-2 py-1">Industry Standard</th>
                            <th className="border px-2 py-1">HBC Simulator</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="border px-2 py-1"># of Features</td>
                            <td className="border px-2 py-1">5–7</td>
                            <td className="border px-2 py-1">31</td>
                          </tr>
                          <tr>
                            <td className="border px-2 py-1">Missing Data Handling</td>
                            <td className="border px-2 py-1">Omitted / Imputed</td>
                            <td className="border px-2 py-1">Bridging Algorithm (0% loss)</td>
                          </tr>
                          <tr>
                            <td className="border px-2 py-1">Individual Variation</td>
                            <td className="border px-2 py-1">Often ignored</td>
                            <td className="border px-2 py-1">Modeled (SD=0.17)</td>
                          </tr>
                          <tr>
                            <td className="border px-2 py-1">Realism Adjustments</td>
                            <td className="border px-2 py-1">Post-hoc</td>
                            <td className="border px-2 py-1">Built-in controls</td>
                          </tr>
                        </tbody>
                      </table>
                    </Tab.Panel>
                  </Tab.Panels>
                </Tab.Group>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
}

export default ModelInfoModal;
