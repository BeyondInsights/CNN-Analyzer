// src/lib/calculations.ts

import type { 
  ProductSetupConfig, 
  RespondentWithParams, 
  SimulationOptions, 
  MarketFactors,
  SimulationResults,
  TakeRate,
  SegmentResults 
} from './types';

/**
 * Computes utilities for a single product/respondent pair.
 */
function calculateUtility(
  product: ProductSetupConfig,
  resp: RespondentWithParams,
  options: SimulationOptions
): number {
  const p = resp.individualParams;
  let u = p.base[product.product] ?? 0;

  // Price effect with safety check
  const safePrice = Math.max(0.01, product.monthlyRate);
  const logP = Math.log(safePrice);
  
  // Apply tiered price sensitivity if enabled
  let priceLinear = p.price.linear;
  if (options.enablePriceTiers) {
    const threshold = options.priceThreshold ?? 12;
    if (product.monthlyRate < threshold) {
      priceLinear *= options.lowPriceMultiplier ?? 1.3;
    } else {
      priceLinear *= options.highPriceMultiplier ?? 0.8;
    }
  }
  
  u += priceLinear * logP;
  u += p.price.squared * logP * logP;

  // Vertical count effect
  const vc = Math.min(product.verticals.length, 3);
  u += p.verticalCount[vc.toString()] ?? 0;  // Convert to string key

  // Individual vertical utilities
  for (const v of product.verticals) {
    u += p.verticals[v] ?? 0;
  }

  // Individual feature utilities
  const features = p.features || p.all_features || {};
  
  // Handle reader features
  const readerFeatures = features.reader || features.readerFeatures || {};
  Object.entries(readerFeatures).forEach(([f, val]) => {
    if (product.readerFeatures?.includes(f)) u += val;
  });

  // Handle streaming features
  const streamingFeatures = features.streaming || features.streamingFeatures || {};
  Object.entries(streamingFeatures).forEach(([f, val]) => {
    if (product.streamingFeatures?.includes(f)) u += val;
  });

  return u;
}

/**
 * Calculate market adjustment factor
 */
function calculateMarketAdjustment(factors: MarketFactors): number {
  const adj = 
    factors.baseConversion *
    (factors.awareness / 100) *
    (factors.distribution / 100) *
    (factors.competitive / 100) *
    (factors.marketing / 100) *
    ((factors.yearOneAdoption || 100) / 100);
  
  return adj;
}

/**
 * Get segment key for a respondent
 */
function getSegmentKey(resp: RespondentWithParams): string {
  const gender = resp.gender || 'Unknown';
  const age = resp.ageGroup || 'Unknown';
  return `${gender}|${age}`;
}

/**
 * Given respondents with params, product configs, and options,
 * returns independent take rates, subscriber counts & revenue.
 */
export function computeTakeRates(
  respondents: RespondentWithParams[],
  products: ProductSetupConfig[],
  options: SimulationOptions,
  marketFactors?: MarketFactors,
  TAM: number = 50000000
): SimulationResults {
  if (!respondents.length || !products.length) {
    return {
      takeRates: [],
      diagnostics: {
        totalRespondents: 0,
        totalWeight: 0,
        averageDRN: 0,
        marketAdjustmentFactor: 0
      }
    };
  }

  // Default market factors if not provided
  const mktFactors: MarketFactors = marketFactors ?? {
    baseConversion: 0.5,
    awareness: 70,
    distribution: 85,
    competitive: 90,
    marketing: 80,
    yearOneAdoption: 65
  };

  // Calculate market adjustment multiplier
  const marketAdjustment = calculateMarketAdjustment(mktFactors);

  // Include "None" option at index 0
  const all = [
    { 
      product: 'None', 
      monthlyRate: 0, 
      readerFeatures: [], 
      streamingFeatures: [], 
      verticals: [], 
      isActive: true, 
      pricingType: 'monthly' as const, 
      discount: 'none' as const
    } as ProductSetupConfig,
    ...products
  ];

  // Accumulate weighted takers per product and segment
  const weightedTakers: Record<string, number> = {};
  const segmentTakers: Record<string, Record<string, number>> = {};
  let totalWeight = 0;
  let drnSum = 0;

  for (const resp of respondents) {
    const weight = resp.weight || 1;
    totalWeight += weight;
    
    // Clamp DRN to valid range
    const drnClamped = Math.max(0.1, Math.min(0.99, resp.drn));
    drnSum += drnClamped * weight;

    // 1) Compute utilities
    const utils = all.map(prod =>
      prod.product === 'None' ? 0 : calculateUtility(prod, resp, options)
    );

    // 2) Softmax with numerical stability
    const M = Math.max(...utils);
    const exps = utils.map(u => Math.exp(u - M));
    const sumExp = exps.reduce((a, b) => a + b, 0) || 1;
    const probs = exps.map(e => e / sumExp);

    // 3) Apply DRN
    const drnProbs = probs.map(p => p * drnClamped);

    // 4) Get segment key
    const segKey = getSegmentKey(resp);
    if (!segmentTakers[segKey]) {
      segmentTakers[segKey] = {};
    }

    // 5) Threshold & allocation
    if (options.allocationMethod === 'proportional') {
      drnProbs.forEach((p, i) => {
        if (i > 0 && p >= options.takeThreshold) {
          const prodName = all[i].product;
          weightedTakers[prodName] = (weightedTakers[prodName] || 0) + weight;
          segmentTakers[segKey][prodName] = (segmentTakers[segKey][prodName] || 0) + weight;
        }
      });
    } else {
      // Winner-takes-all
      const maxIdx = drnProbs.indexOf(Math.max(...drnProbs));
      if (maxIdx > 0 && drnProbs[maxIdx] >= options.takeThreshold) {
        const prodName = all[maxIdx].product;
        weightedTakers[prodName] = (weightedTakers[prodName] || 0) + weight;
        segmentTakers[segKey][prodName] = (segmentTakers[segKey][prodName] || 0) + weight;
      }
    }
  }

  // Calculate average DRN
  const avgDRN = totalWeight > 0 ? drnSum / totalWeight : 0;

  // Build take rates for each product
  const takeRates: TakeRate[] = products.map(prod => {
    const w = weightedTakers[prod.product] || 0;
    const rawTakeRate = (w / totalWeight) * 100;
    const adjustedTakeRate = rawTakeRate * marketAdjustment;
    const subs = (adjustedTakeRate / 100) * TAM;
    const rev = subs * prod.monthlyRate * 12;
    
    return {
      productName: prod.product,
      takeRate: rawTakeRate,
      adjustedTakeRate: adjustedTakeRate,
      subscribers: Math.round(subs),
      revenue: Math.round(rev)
    };
  });

  // Build segment results
  const segmentResults: SegmentResults = {};
  for (const [segKey, segProds] of Object.entries(segmentTakers)) {
    const segmentTakeRates: TakeRate[] = products.map(prod => {
      const w = segProds[prod.product] || 0;
      const rawTakeRate = (w / totalWeight) * 100;
      const adjustedTakeRate = rawTakeRate * marketAdjustment;
      const subs = (adjustedTakeRate / 100) * TAM;
      const rev = subs * prod.monthlyRate * 12;
      
      return {
        productName: prod.product,
        takeRate: rawTakeRate,
        adjustedTakeRate: adjustedTakeRate,
        subscribers: Math.round(subs),
        revenue: Math.round(rev)
      };
    });

    const totalSubs = segmentTakeRates.reduce((sum, tr) => sum + tr.subscribers, 0);
    const totalRev = segmentTakeRates.reduce((sum, tr) => sum + tr.revenue, 0);

    segmentResults[segKey] = {
      takeRates: segmentTakeRates,
      totalSubscribers: totalSubs,
      totalRevenue: totalRev
    };
  }

  return {
    takeRates,
    segmentResults,
    diagnostics: {
      totalRespondents: respondents.length,
      totalWeight: totalWeight,
      averageDRN: avgDRN,
      marketAdjustmentFactor: marketAdjustment
    }
  };
}

export const VALID_VERTICALS = [
  'D1_1', 'D1_2', 'D1_3', 'D1_4',
  'D2_1', 'D2_2', 'D2_3', 'D2_4',
  'B1', 'B2'
];

export function validateProductData(products: ProductSetupConfig[]): string[] {
  const errors: string[] = [];
  
  products.forEach((product, index) => {
    if (!product.product || product.product.trim() === '') {
      errors.push(`Product ${index + 1}: Missing product name`);
    }
    
    if (!product.monthlyRate || product.monthlyRate <= 0) {
      errors.push(`${product.product}: Invalid monthly rate`);
    }
    
    const hasReaderFeatures = product.readerFeatures && product.readerFeatures.length > 0;
    const hasStreamingFeatures = product.streamingFeatures && product.streamingFeatures.length > 0;
    
    if (!hasReaderFeatures && !hasStreamingFeatures) {
      errors.push(`${product.product}: No features selected`);
    }
    
    if (product.verticals) {
      product.verticals.forEach(v => {
        if (!VALID_VERTICALS.includes(v)) {
          errors.push(`${product.product}: Invalid vertical "${v}"`);
        }
      });
    }
  });
  
  return errors;
}

export function applyMarketFactors(baseRate: number, factors: MarketFactors): number {
  const safeFactors = {
    awareness: Math.max(0, Math.min(100, factors.awareness || 70)),
    distribution: Math.max(0, Math.min(100, factors.distribution || 85)),
    competitive: Math.max(0, Math.min(100, factors.competitive || 90)),
    marketing: Math.max(0, Math.min(100, factors.marketing || 80)),
    yearOneAdoption: Math.max(0, Math.min(100, factors.yearOneAdoption || 100))
  };
  
  let adjustedRate = baseRate * (factors.baseConversion || 0.5);
  adjustedRate *= (safeFactors.awareness / 100);
  adjustedRate *= (safeFactors.distribution / 100);
  adjustedRate *= (safeFactors.competitive / 100);
  adjustedRate *= (safeFactors.marketing / 100);
  adjustedRate *= (safeFactors.yearOneAdoption / 100);
  
  return adjustedRate;
}